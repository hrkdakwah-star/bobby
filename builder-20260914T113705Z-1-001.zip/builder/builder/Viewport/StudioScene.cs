using System;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.IO;
using Gdi = System.Drawing;
using GdiImaging = System.Drawing.Imaging;
using GdiText = System.Drawing.Text;
using OpenTK.Graphics.OpenGL;
using OpenTK.Mathematics;
using StbImageSharp;

namespace builder.Viewport;

/// <summary>Which manipulator the viewport draws for the selection.</summary>
public enum GizmoKind
{
    None,
    Move,
    Scale,
    Rotate,
}

/// <summary>Lit multi-object scene (Blinn-Phong + rim + fog), one shared cube mesh.</summary>
public sealed class StudioScene : IDisposable
{
    private const string DecalVertexSrc = @"#version 460 core
layout(location=0) in vec3 vPosition;
layout(location=1) in vec2 vUv;
uniform mat4 uMVP;
out vec2 fUv;
void main(){ fUv=vUv; gl_Position=uMVP*vec4(vPosition,1.0); }";
    private const string DecalFragmentSrc = @"#version 460 core
in vec2 fUv;
uniform sampler2D uImage;
uniform float uTransparency;
uniform float uBlur;
out vec4 oColor;
void main(){
 vec2 px=1.0/vec2(textureSize(uImage,0));
 vec4 c=texture(uImage,fUv);
 if(uBlur>0.001){
  // 9-tap Gaussian (center + cross + diagonals): soft without box artifacts.
  // Mipmapped sampler keeps it stable at distance.
  vec2 d=px*uBlur*4.0;
  vec4 acc=c*0.20;
  acc+=texture(uImage,fUv+vec2(d.x,0))*0.12;
  acc+=texture(uImage,fUv-vec2(d.x,0))*0.12;
  acc+=texture(uImage,fUv+vec2(0,d.y))*0.12;
  acc+=texture(uImage,fUv-vec2(0,d.y))*0.12;
  acc+=texture(uImage,fUv+d)*0.08;
  acc+=texture(uImage,fUv-d)*0.08;
  acc+=texture(uImage,fUv+vec2(d.x,-d.y))*0.08;
  acc+=texture(uImage,fUv+vec2(-d.x,d.y))*0.08;
  c=acc;
 }
 c.a*=1.0-uTransparency;
 if(c.a<0.004) discard;
 oColor=c;
}";
    private const string VertexSrc = @"#version 460 core
in vec3 vPosition;
in vec3 vNormal;
uniform mat4 uMVP;
uniform mat4 uModel;
uniform mat3 uNormalMat;
out vec3 fWorldPos;
out vec3 fNormal;
void main()
{
    vec4 wp = uModel * vec4(vPosition, 1.0);
    fWorldPos = wp.xyz;
    fNormal = uNormalMat * vNormal;
    gl_Position = uMVP * vec4(vPosition, 1.0);
}";

    private const string FragmentSrc = @"#version 460 core
in vec3 fWorldPos;
in vec3 fNormal;
uniform vec3 uColor;
uniform vec3 uCamPos;
uniform float uPulse;
uniform vec3 uFogColor;
uniform float uFogDensity;
uniform float uMetallic;
uniform float uShininess;
uniform float uOpacity;
uniform float uEmissive;
uniform sampler2DShadow uShadowMap;
uniform mat4 uLightVP;
uniform float uShadowsOn;
uniform float uShadowSize;
uniform float uShadowDistance;
uniform vec3 uSunDir;
uniform vec3 uSunColor;
uniform float uSunI;
uniform float uAmbient;
uniform float uReflectance;
out vec4 oColor;

// How far from the camera shadows render: full strength nearby, fading to
// fully lit at uShadowDistance (Settings > Shadow distance).
float ShadowRange(vec3 wp)
{
    float camDist = length(uCamPos - wp);
    return 1.0 - smoothstep(uShadowDistance * 0.75, uShadowDistance, camDist);
}

// Tight core stays crisp; a wide ring blends in only where the core is
// fractional (i.e. on shadow edges), so interiors stay deep and lit stays lit.
float ShadowFactor(vec3 wp, vec3 n)
{
    vec4 lp = uLightVP * vec4(wp + n * 0.02, 1.0);
    vec3 c = lp.xyz / lp.w * 0.5 + 0.5;
    if (c.x < 0.0 || c.x > 1.0 || c.y < 0.0 || c.y > 1.0 || c.z > 1.0) return 1.0;
    vec2 texel = vec2(1.0 / uShadowSize);
    // Low-resolution maps need a larger receiver bias. A fixed bias causes
    // quantized self-shadow acne (the distracting dotted pattern) at 512px.
    float depth = c.z - (0.0008 + 1.5 / uShadowSize);
    float core = 0.0;
    core += texture(uShadowMap, vec3(c.xy + vec2(-0.5, -0.5) * texel, depth));
    core += texture(uShadowMap, vec3(c.xy + vec2( 0.5, -0.5) * texel, depth));
    core += texture(uShadowMap, vec3(c.xy + vec2(-0.5,  0.5) * texel, depth));
    core += texture(uShadowMap, vec3(c.xy + vec2( 0.5,  0.5) * texel, depth));
    core /= 4.0;
    float edge = core * (1.0 - core) * 4.0; // 0 in flat areas, 1 mid-transition
    if (edge > 0.001)
    {
        float wide = 0.0;
        wide += texture(uShadowMap, vec3(c.xy + vec2(-2.0, -2.0) * texel, depth));
        wide += texture(uShadowMap, vec3(c.xy + vec2( 2.0, -2.0) * texel, depth));
        wide += texture(uShadowMap, vec3(c.xy + vec2(-2.0,  2.0) * texel, depth));
        wide += texture(uShadowMap, vec3(c.xy + vec2( 2.0,  2.0) * texel, depth));
        core = mix(core, wide / 4.0, clamp(edge * 1.5, 0.0, 1.0));
    }
    return mix(1.0, core, uShadowsOn * ShadowRange(wp));
}
void main()
{
    vec3 N = normalize(fNormal);
    vec3 V = normalize(uCamPos - fWorldPos);
    vec3 L = normalize(uSunDir); // key sun (Lighting > Sun > Direction)

    float sun = ShadowFactor(fWorldPos, N);
    float diff = max(dot(N, L), 0.0);
    vec3 H = normalize(L + V);
    // Metals: tinted specular, suppressed diffuse. Plastics: white specular.
    vec3 specTint = mix(vec3(1.0), uColor, uMetallic);
    vec3 diffTint = uColor * (1.0 - uMetallic * 0.75);
    float spec = pow(max(dot(N, H), 0.0), uShininess) * mix(0.35, 1.2, uMetallic);

    float hemi = 0.5 + 0.5 * N.y; // sky/ground ambient tint
    vec3 ambient = mix(vec3(0.22, 0.22, 0.25), vec3(0.42, 0.44, 0.48), hemi);

    float rim = pow(1.0 - max(dot(N, V), 0.0), 3.0) * (0.30 + 0.40 * uMetallic);

    vec3 lit = diffTint * (ambient * uAmbient + diff * uSunColor * uSunI * sun)
             + specTint * spec * uSunI * sun
             + vec3(0.45, 0.65, 1.0) * rim;

    // Faked reflection (no env map): sky gradient + sun glint in the mirror dir.
    vec3 R = reflect(-V, N);
    vec3 env = mix(uFogColor * 0.55, vec3(0.55, 0.70, 0.92), clamp(R.y * 0.5 + 0.5, 0.0, 1.0));
    env += vec3(1.0, 0.96, 0.90) * pow(max(dot(R, L), 0.0), 24.0) * sun;
    lit += uReflectance * env;
    lit += uColor * (uEmissive + uPulse); // neon glow + selection glow

    float dist = length(uCamPos - fWorldPos);
    float fog = 1.0 - exp(-dist * dist * uFogDensity * uFogDensity);
    lit = mix(lit, uFogColor, clamp(fog, 0.0, 1.0));

    oColor = vec4(lit, uOpacity);
}";

    internal struct Vertex
    {
        public Vector3 Position;
        public Vector3 Normal;
        public Vertex(Vector3 p, Vector3 n) { Position = p; Normal = n; }
    }

    private sealed class Mesh
    {
        public int Vao;
        public int Vbo;
        public int Count;
    }

    /// <summary>Pale horizon haze, also the clear color (Lighting &gt; Atmosphere &gt; Fog Color).</summary>
    public Vector3 FogColor { get; set; } = new(0.55f, 0.62f, 0.72f);

    /// <summary>Exponential fog density. Tiny values; 0 disables.</summary>
    public float FogDensity { get; set; } = 0.012f;

    private const string SkyVertexSrc = @"#version 460 core
in vec3 vPosition;
uniform mat4 uMVP;
out vec3 fDir;
void main()
{
    fDir = vPosition;
    gl_Position = uMVP * vec4(vPosition, 1.0);
}";

    private const string SkyFragmentSrc = @"#version 460 core
in vec3 fDir;
uniform vec3 uSunDir;
uniform vec3 uSunTint;
uniform float uSunI;
uniform float uHaze;
out vec4 oColor;

const float PI = 3.14159265;

// Compact single-scattering analytic sky: wavelength-weighted Rayleigh for
// blue, forward-lobed Mie (Henyey-Greenstein) for haze and sun glow, ozone
// absorption so horizons go pale instead of green. All direction-based, so it
// needs no textures and works at any scene scale.
void main()
{
    vec3 d = normalize(fDir);
    vec3 sunDir = normalize(uSunDir); // matches key light

    const vec3 betaR = vec3(0.046, 0.108, 0.265);  // Rayleigh 1/lambda^4, zenith depths
    const vec3 betaO3 = vec3(0.006, 0.014, 0.003); // ozone Chappuis band
    vec3 beta = betaR + vec3(uHaze) + betaO3;

    float sunI = 22.0 * uSunI;
    const float g = 0.76; // Mie asymmetry (forward scattering)

    // Plane-parallel optical depth: ~1 overhead, deepening toward horizon.
    float h = max(d.y, 0.02);
    float viewDepth = min(1.0 / h, 30.0);
    float cosTheta = dot(d, sunDir);

    // Sunlight reddened on its way down (longer path at low sun).
    float sunAirMass = 1.0 / max(sunDir.y, 0.05);
    vec3 sunAtten = exp(-beta * sunAirMass);

    // Closed-form single-scatter integral along the view ray.
    vec3 transmittance = exp(-beta * viewDepth);
    vec3 scatterIntegral = (vec3(1.0) - transmittance) / beta;

    float phaseR = 3.0 / (16.0 * PI) * (1.0 + cosTheta * cosTheta);
    float denom = max(1.0 + g * g - 2.0 * g * cosTheta, 1e-4);
    float phaseM = (1.0 - g * g) / (4.0 * PI * pow(denom, 1.5));

    vec3 sky = sunI * uSunTint * (phaseR * betaR + phaseM * uHaze) * scatterIntegral * sunAtten;

    // Sun disk with soft limb + tight corona.
    float disk = smoothstep(0.99988, 0.99996, cosTheta);
    sky += uSunTint * disk * 4.0;
    sky += uSunTint * pow(max(cosTheta, 0.0), 800.0) * 0.6;

    // Below the horizon: melt into dark blue ground haze.
    vec3 ground = vec3(0.045, 0.085, 0.175);
    sky = mix(sky, ground, smoothstep(0.0, 0.2, -d.y));

    oColor = vec4(sky, 1.0);
}";

    /// <summary>Skybox half-size. Corners (~95) stay well inside the far plane (500).</summary>
    private const float SkyHalf = 55f;

    private static readonly Vector3 DefaultSun = Vector3.Normalize(new Vector3(0.5f, 0.8f, 0.6f));

    private Vector3 _sunDirection = DefaultSun;

    /// <summary>Key sun direction (Lighting &gt; Sun &gt; Direction). Retargets light + sky + shadows.</summary>
    public Vector3 SunDirection
    {
        get => _sunDirection;
        set
        {
            if (value.LengthSquared > 1e-8f) _sunDirection = Vector3.Normalize(value);
            InvalidateShadows(); // light space moved
        }
    }

    /// <summary>Sunlight tint for parts and sky (Lighting &gt; Sun &gt; Color).</summary>
    public Vector3 SunColor { get; set; } = new(1f, 0.97f, 0.92f);

    /// <summary>Sunlight multiplier 0-2 (Lighting &gt; Sun &gt; Intensity).</summary>
    public float SunIntensity { get; set; } = 1f;

    /// <summary>Clock time 0-24h driving sun, sky and ambient. Set via <see cref="SetTimeOfDay"/>.</summary>
    public float TimeOfDay { get; private set; } = 10f;

    /// <summary>
    /// Drive sun direction/color/intensity and ambient from a 24h clock: rise ~6h,
    /// noon peak, set ~18h, dim blue night. Pure math (no GL): safe headless.
    /// </summary>
    public void SetTimeOfDay(float t)
    {
        t = Math.Clamp(t, 0f, 24f);
        TimeOfDay = t;
        float sine = MathF.Sin((t - 6f) / 12f * MathF.PI); // 1 noon, 0 at 6h/18h, -1 midnight
        float day = Math.Clamp(sine, 0f, 1f);
        float el = Math.Max(sine, 0.06f); // never below the horizon (no under-lighting)
        float ce = MathF.Sqrt(Math.Max(1f - el * el, 0.01f));
        float az = t / 24f * MathF.PI * 2f;
        SunDirection = new Vector3(MathF.Cos(az) * ce, el, MathF.Sin(az) * ce);
        float duskW = Math.Clamp(1f - day * 2.5f, 0f, 1f) * (sine > -0.08f ? 1f : 0f);
        var dayCol = new Vector3(1f, 0.97f, 0.92f);
        var duskCol = new Vector3(1f, 0.55f, 0.30f);
        var nightCol = new Vector3(0.45f, 0.60f, 1f);
        SunColor = Vector3.Lerp(Vector3.Lerp(nightCol, dayCol, day), duskCol, duskW);
        SunIntensity = 0.06f + day * 0.94f; // moonlight floor at night
        AmbientBoost = 0.22f + day * 0.78f;
        InvalidateShadows(); // sun moved
    }

    /// <summary>Sky/ground ambient multiplier 0-2 (Lighting &gt; Ambient).</summary>
    public float AmbientBoost { get; set; } = 1f;

    /// <summary>Sky haze (Mie amount) 0-0.05 (Lighting &gt; Atmosphere &gt; Haze).</summary>
    public float SkyHaze { get; set; } = 0.012f;

    private const string DepthVertexSrc = @"#version 460 core
layout(location = 0) in vec3 vPosition;
uniform mat4 uLightMVP;
void main()
{
    gl_Position = uLightMVP * vec4(vPosition, 1.0);
}";

    private const string DepthFragmentSrc = @"#version 460 core
void main()
{
}";

    private const int ShadowSize = 1024;

    /// <summary>Shadow frustum half-extent in studs (Settings &gt; Shadow distance).</summary>
    public float ShadowDistance { get; set; } = 20f;

    /// <summary>Active shadow map resolution. Change via <see cref="RequestShadowSize"/>.</summary>
    public int ShadowMapSize { get; private set; } = ShadowSize;
    private int _pendingShadowSize = ShadowSize;

    /// <summary>Queue a shadow map resize (256/512/1024/2048/4096); applied on the next frame.</summary>
    public void RequestShadowSize(int size)
    {
        _pendingShadowSize = size is 256 or 512 or 1024 or 2048 or 4096 ? size : ShadowSize;
    }

    /// <summary>
    /// Effective map size: scales the quality request with render distance so texel
    /// density (and hence shadow crispness) stays constant — distance never costs
    /// quality. Snapped up to a power of two, clamped to 256..4096. Past the cap
    /// (Ultra quality at Ultra/Maximum distance) density degrades gracefully;
    /// everywhere else it holds within one snap step.
    /// </summary>
    private int WantedShadowSize()
    {
        long want = (long)Math.Ceiling(_pendingShadowSize * (ShadowDistance / 20.0));
        want = Math.Clamp(want, 256, 4096);
        int p = 256;
        while (p < want) p <<= 1;
        return Math.Min(p, 4096);
    }

    private const float FovDefault = 45f;

    /// <summary>Vertical field of view in degrees (lives in render, pick, gizmo math).</summary>
    public float FovDeg { get; set; } = FovDefault;

    // ---------- move gizmo ----------
    private int _gizmoProgram;
    private int _gizmoMvpLoc = -1;
    private int _gizmoColorLoc = -1;
    private readonly int[] _gizmoVaos = new int[3];
    private readonly int[] _gizmoVbos = new int[3];
    private readonly uint[] _gizmoCounts = new uint[3];
    private readonly int[] _scaleVaos = new int[3];
    private readonly int[] _scaleVbos = new int[3];
    private readonly uint[] _scaleCounts = new uint[3];
    private readonly int[] _ringVaos = new int[3];
    private readonly int[] _ringVbos = new int[3];
    private readonly uint[] _ringCounts = new uint[3];

    /// <summary>Hovered arrow (0=X, 1=Y, 2=Z, -1=none). Set by the UI for highlight.</summary>
    public int HoverAxis { get; set; } = -1;
    /// <summary>Arrow currently being dragged. Set by the UI for highlight.</summary>
    public int ActiveAxis { get; set; } = -1;
    /// <summary>Which gizmo the active tool shows. None hides it.</summary>
    public GizmoKind ActiveGizmo { get; set; } = GizmoKind.Move;

    public static Vector3 GizmoAxisVec(int a) =>
        a == 0 ? Vector3.UnitX : a == 2 ? Vector3.UnitZ : Vector3.UnitY;

    /// <summary>Gizmo axis in world space: follows the selection's orientation
    /// (world axes when nothing is selected).</summary>
    public Vector3 GizmoAxis(int a)
    {
        var q = Selected?.Orientation ?? Quaternion.Identity;
        return Vector3.Transform(GizmoAxisVec(a), q);
    }

    private int _program;
    private int _mvpLoc = -1;
    private int _modelLoc = -1;
    private int _normalLoc = -1;
    private int _colorLoc = -1;
    private int _camLoc = -1;
    private int _pulseLoc = -1;
    private int _fogColorLoc = -1;
    private int _fogDensityLoc = -1;
    private int _metallicLoc = -1;
    private int _shininessLoc = -1;
    private int _opacityLoc = -1;
    private int _emissiveLoc = -1;
    private int _shadowMapLoc = -1;
    private int _lightVpLoc = -1;
    private int _shadowsOnLoc = -1;
    private int _shadowSizeLoc = -1;
    private int _shadowDistanceLoc = -1;
    private int _sunDirLoc = -1;
    private int _sunColorLoc = -1;
    private int _sunILoc = -1;
    private int _ambientLoc = -1;
    private int _reflectanceLoc = -1;
    private int _skyProgram;
    private int _skyMvpLoc = -1;
    private int _skySunDirLoc = -1;
    private int _skySunTintLoc = -1;
    private int _skySunILoc = -1;
    private int _skyHazeLoc = -1;
    private int _skyVao;
    private int _decalProgram;
    private int _decalMvpLoc = -1, _decalImageLoc = -1, _decalTransparencyLoc = -1, _decalBlurLoc = -1;
    private int _decalVao, _decalVbo;
    private readonly Dictionary<string, int> _decalTextures = new(StringComparer.OrdinalIgnoreCase);
    private readonly Dictionary<string, int> _textTextures = new(StringComparer.Ordinal);

    // ---------- directional shadow map ----------
    private int _depthProgram;
    private int _depthMvpLoc = -1;
    private int _shadowFbo;
    private int _shadowTex;

    /// <summary>Master shadow toggle (View tab). Off skips the depth pass.</summary>
    public bool ShadowsEnabled { get; set; } = true;

    private bool _shadowDirty = true; // light space is static: re-render depth only when set

    /// <summary>Last snapped shadow focus (texel grid). A cell change re-renders the map.</summary>
    private Vector3 _lastShadowFocus = new(float.MaxValue, 0f, 0f);

    /// <summary>Mark the cached shadow map stale (call when parts move/change).</summary>
    public void InvalidateShadows() => _shadowDirty = true;

    /// <summary>Shader compiler/linker messages from the last Initialize (empty = clean).</summary>
    public string InitLog { get; private set; } = "";

    private readonly Dictionary<ShapeKind, Mesh> _meshes = new();

    // Reused scratch for the transparent pass (zero per-frame allocation).
    private readonly List<SceneObject> _transparent = new();

    private Mesh UploadMesh(Vertex[] verts)
    {
        var mesh = new Mesh
        {
            Vao = GL.GenVertexArray(),
            Vbo = GL.GenBuffer(),
            Count = verts.Length,
        };
        GL.BindVertexArray(mesh.Vao);
        GL.BindBuffer(BufferTarget.ArrayBuffer, mesh.Vbo);
        GL.BufferData(BufferTarget.ArrayBuffer, verts.Length * Unsafe.SizeOf<Vertex>(), verts, BufferUsageHint.StaticDraw);
        int pos = GL.GetAttribLocation(_program, "vPosition");
        int nrm = GL.GetAttribLocation(_program, "vNormal");
        GL.EnableVertexAttribArray(pos);
        GL.VertexAttribPointer(pos, 3, VertexAttribPointerType.Float, false, Unsafe.SizeOf<Vertex>(), 0);
        GL.EnableVertexAttribArray(nrm);
        GL.VertexAttribPointer(nrm, 3, VertexAttribPointerType.Float, false, Unsafe.SizeOf<Vertex>(), Unsafe.SizeOf<Vector3>());
        GL.BindVertexArray(0);
        return mesh;
    }

    private bool _initialized;
    private bool _disposed;
    private readonly Stopwatch _clock = Stopwatch.StartNew();
    private double _lastTime;

    public double Fps { get; private set; }

    /// <summary>EMA of CPU milliseconds spent submitting a frame (not GPU time).</summary>
    public double CpuMs { get; private set; }

    public List<SceneObject> Objects { get; } = new();
    public SceneObject? Selected { get; set; }

    /// <summary>When true, a physics simulation owns object transforms (Play mode).</summary>
    public bool PhysicsDriven { get; set; }

    // ---------- Roblox-Studio-style free camera ----------
    // Right-drag looks, WASD+QE flies (while right button held), wheel zooms,
    // middle-drag pans, F resets. Yaw -90 / pitch -10 faces the origin from +Z.
    //
    // All motion is smoothed: look eases toward its target, fly velocity ramps
    // up/down exponentially, and wheel input becomes a decaying zoom impulse.
    // Lambdas are frame-rate independent (higher = snappier).
    public Vector3 Position { get; set; } = new(0, 1.5f, 8f);

    private float _yaw = -90f;
    private float _pitch = -10f;
    private float _targetYaw = -90f;
    private float _targetPitch = -10f;
    private Vector3 _flyVel = Vector3.Zero;
    private float _zoomVel;

    public float Yaw
    {
        get => _yaw;
        set { _yaw = value; _targetYaw = value; }
    }

    public float Pitch
    {
        get => _pitch;
        set { _pitch = value; _targetPitch = value; }
    }

    public float LookResponsiveness { get; set; } = 18f;
    public float MoveResponsiveness { get; set; } = 10f;
    public float ZoomDecay { get; set; } = 10f;
    public float ScaleResponsiveness { get; set; } = 14f;
    public float LookSensitivity { get; set; } = 0.25f;
    public float MoveSpeed { get; set; } = 8f;
    public float SlowMultiplier { get; set; } = 0.25f;

    /// <summary>Flip vertical look (mouse up looks down).</summary>
    public bool InvertLookY { get; set; }

    /// <summary>Selection pulse strength 0-1 (0 = no glow).</summary>
    public float PulseStrength { get; set; } = 1f;

    /// <summary>Play-mode follow target (the avatar). Null = free camera.</summary>
    public SceneObject? FollowTarget { get; set; }

    /// <summary>Third-person orbit distance, driven by the wheel in play mode.</summary>
    public float FollowDistance { get; set; } = 12f;

    /// <summary>Focus height above the target center (0 = dead-center on the avatar).</summary>
    public float FollowHeight { get; set; } = 0f;

    /// <summary>Fly input for the current frame. X = strafe (+right), Y = vertical (+up, world), Z = forward.</summary>
    public Vector3 FlyInput { get; set; } = Vector3.Zero;
    public bool FlySlow { get; set; }

    public Vector3 Forward
    {
        get
        {
            float yaw = MathHelper.DegreesToRadians(Yaw);
            float pitch = MathHelper.DegreesToRadians(Pitch);
            return new Vector3(
                MathF.Cos(pitch) * MathF.Cos(yaw),
                MathF.Sin(pitch),
                MathF.Cos(pitch) * MathF.Sin(yaw));
        }
    }

    public Vector3 Right => Vector3.Normalize(Vector3.Cross(Forward, Vector3.UnitY));
    public Vector3 CameraUp => Vector3.Normalize(Vector3.Cross(Right, Forward));

    /// <summary>Mouse-look: drag right to turn right, drag up to look up (unless inverted).</summary>
    public void Look(float dx, float dy)
    {
        _targetYaw += dx * LookSensitivity;
        float pitchDelta = dy * LookSensitivity;
        _targetPitch = Math.Clamp(_targetPitch + (InvertLookY ? pitchDelta : -pitchDelta), -89f, 89f);
    }

    /// <summary>Pan: drag moves the camera across its own plane.</summary>
    public void Pan(float dx, float dy)
    {
        float k = Math.Clamp(Position.Length * 0.0016f, 0.002f, 0.05f);
        Position += (-Right * dx + CameraUp * dy) * k;
    }

    /// <summary>Wheel zoom: feeds a decaying velocity impulse (smooth glide).</summary>
    public void Dolly(float amount)
    {
        _zoomVel += amount * ZoomDecay;
    }

    public void ResetCamera()
    {
        Position = new Vector3(0, 1.5f, 8f);
        Yaw = -90f;   // setters sync target + actual, stopping all drift
        Pitch = -10f;
        _flyVel = Vector3.Zero;
        _zoomVel = 0f;
    }

    /// <summary>Frame a point: keep the view direction, move so the target
    /// fits the viewport given its bounding radius.</summary>
    public void FocusOn(Vector3 target, float radius)
    {
        float dist = Math.Clamp(
            Math.Max(radius, 0.5f) / MathF.Tan(MathHelper.DegreesToRadians(FovDeg / 2f)) * 1.4f,
            3f, 100f);
        Position = target - Forward * dist;
        _flyVel = Vector3.Zero;
        _zoomVel = 0f;
    }

    private const string GizmoVertexSrc = @"#version 460 core
in vec3 vPosition;
uniform mat4 uMVP;
void main()
{
    gl_Position = uMVP * vec4(vPosition, 1.0);
}";

    private const string GizmoFragmentSrc = @"#version 460 core
uniform vec3 uColor;
out vec4 oColor;
void main()
{
    oColor = vec4(uColor, 1.0);
}";

    /// <summary>Arrow mesh along +Y (shaft box + cone head), as a triangle soup.</summary>
    private static List<Vector3> BuildArrowTris()
    {
        var tris = new List<Vector3>();
        void Tri(Vector3 a, Vector3 b, Vector3 c) { tris.Add(a); tris.Add(b); tris.Add(c); }

        float r = 0.03f, y0 = 0.02f, y1 = 0.68f;
        Vector3[] q =
        {
            new(-r, y0, -r), new(r, y0, -r), new(r, y1, -r), new(-r, y1, -r),
            new(-r, y0,  r), new(r, y0,  r), new(r, y1,  r), new(-r, y1,  r),
        };
        int[][] faces =
        {
            new[] { 0, 1, 2, 3 }, new[] { 5, 4, 7, 6 }, new[] { 4, 0, 3, 7 },
            new[] { 1, 5, 6, 2 }, new[] { 3, 2, 6, 7 }, new[] { 4, 5, 1, 0 },
        };
        foreach (var f in faces)
        {
            Tri(q[f[0]], q[f[1]], q[f[2]]);
            Tri(q[f[0]], q[f[2]], q[f[3]]);
        }

        const int N = 12;
        float br = 0.09f, by = 0.68f;
        var tip = new Vector3(0, 1, 0);
        var bc = new Vector3(0, by, 0);
        for (int k = 0; k < N; k++)
        {
            float a0 = k / (float)N * MathF.PI * 2f;
            float a1 = (k + 1) / (float)N * MathF.PI * 2f;
            var p0 = new Vector3(br * MathF.Cos(a0), by, br * MathF.Sin(a0));
            var p1 = new Vector3(br * MathF.Cos(a1), by, br * MathF.Sin(a1));
            Tri(tip, p0, p1);
            Tri(bc, p1, p0);
        }
        return tris;
    }

    /// <summary>Scale-handle mesh along +Y (thin shaft + grab cube), triangle soup.</summary>
    private static List<Vector3> BuildScaleTris()
    {
        var tris = new List<Vector3>();
        void Tri(Vector3 a, Vector3 b, Vector3 c) { tris.Add(a); tris.Add(b); tris.Add(c); }
        void Quad(Vector3 a, Vector3 b, Vector3 c, Vector3 d) { Tri(a, b, c); Tri(a, c, d); }

        float r = 0.025f, y0 = 0.02f, y1 = 0.70f;
        Vector3[] q =
        {
            new(-r, y0, -r), new(r, y0, -r), new(r, y1, -r), new(-r, y1, -r),
            new(-r, y0,  r), new(r, y0,  r), new(r, y1,  r), new(-r, y1,  r),
        };
        Quad(q[0], q[1], q[2], q[3]); Quad(q[5], q[4], q[7], q[6]);
        Quad(q[4], q[0], q[3], q[7]); Quad(q[1], q[5], q[6], q[2]);
        Quad(q[3], q[2], q[6], q[7]); Quad(q[4], q[5], q[1], q[0]);

        float h = 0.08f, cy = 0.84f;
        Vector3[] c =
        {
            new(-h, cy - h, -h), new(h, cy - h, -h), new(h, cy + h, -h), new(-h, cy + h, -h),
            new(-h, cy - h,  h), new(h, cy - h,  h), new(h, cy + h,  h), new(-h, cy + h,  h),
        };
        Quad(c[0], c[1], c[2], c[3]); Quad(c[5], c[4], c[7], c[6]);
        Quad(c[4], c[0], c[3], c[7]); Quad(c[1], c[5], c[6], c[2]);
        Quad(c[3], c[2], c[6], c[7]); Quad(c[4], c[5], c[1], c[0]);
        return tris;
    }

    /// <summary>Upload one +Y mesh baked into all 3 axis orientations (no runtime rotation risk).</summary>
    private void UploadAxisMesh(List<Vector3> baseTris, int[] vaos, int[] vbos, uint[] counts)
    {
        for (int a = 0; a < 3; a++)
        {
            var arr = new Vector3[baseTris.Count];
            for (int k = 0; k < baseTris.Count; k++)
            {
                var v = baseTris[k];
                arr[k] = a == 0 ? new Vector3(v.Y, v.X, v.Z)  // +Y -> +X
                       : a == 2 ? new Vector3(v.X, v.Z, v.Y)  // +Y -> +Z
                       : v;
            }
            vaos[a] = GL.GenVertexArray();
            vbos[a] = GL.GenBuffer();
            GL.BindVertexArray(vaos[a]);
            GL.BindBuffer(BufferTarget.ArrayBuffer, vbos[a]);
            GL.BufferData(BufferTarget.ArrayBuffer, arr.Length * Unsafe.SizeOf<Vector3>(), arr, BufferUsageHint.StaticDraw);
            int gp = GL.GetAttribLocation(_gizmoProgram, "vPosition");
            GL.EnableVertexAttribArray(gp);
            GL.VertexAttribPointer(gp, 3, VertexAttribPointerType.Float, false, Unsafe.SizeOf<Vector3>(), 0);
            GL.BindVertexArray(0);
            counts[a] = (uint)arr.Length;
        }
    }

    /// <summary>(Re)create the shadow depth target at the pending size. GL context required.</summary>
    private void RecreateShadowTarget()
    {
        if (_shadowTex != 0) GL.DeleteTexture(_shadowTex);
        if (_shadowFbo != 0) GL.DeleteFramebuffer(_shadowFbo);
        ShadowMapSize = WantedShadowSize();
        _shadowTex = GL.GenTexture();
        GL.BindTexture(TextureTarget.Texture2D, _shadowTex);
        GL.TexImage2D(TextureTarget.Texture2D, 0, PixelInternalFormat.DepthComponent24,
            ShadowMapSize, ShadowMapSize, 0, PixelFormat.DepthComponent, PixelType.UnsignedInt, IntPtr.Zero);
        GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMinFilter, (int)TextureMinFilter.Linear);
        GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMagFilter, (int)TextureMagFilter.Linear);
        GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureWrapS, (int)TextureWrapMode.ClampToBorder);
        GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureWrapT, (int)TextureWrapMode.ClampToBorder);
        GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureBorderColor, new float[] { 1f, 1f, 1f, 1f });
        // Hardware PCF: single-tap filtered depth compare in the shader.
        GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureCompareMode, (int)TextureCompareMode.CompareRefToTexture);
        GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureCompareFunc, (int)All.Lequal);
        GL.BindTexture(TextureTarget.Texture2D, 0);
        _shadowFbo = GL.GenFramebuffer();
        GL.BindFramebuffer(FramebufferTarget.Framebuffer, _shadowFbo);
        GL.FramebufferTexture2D(FramebufferTarget.Framebuffer, FramebufferAttachment.DepthAttachment,
            TextureTarget.Texture2D, _shadowTex, 0);
        GL.DrawBuffer(DrawBufferMode.None);
        GL.ReadBuffer(ReadBufferMode.None);
        var fbStatus = GL.CheckFramebufferStatus(FramebufferTarget.Framebuffer);
        if (fbStatus != FramebufferErrorCode.FramebufferComplete)
            InitLog += $"Shadow FBO incomplete: {fbStatus}\n";
        GL.BindFramebuffer(FramebufferTarget.Framebuffer, 0);
        InvalidateShadows(); // fresh target holds garbage until re-rendered
    }

    public void Initialize()
    {
        if (_initialized) return;
        _initialized = true;

        _program = CreateProgram(VertexSrc, FragmentSrc);
        _mvpLoc = GL.GetUniformLocation(_program, "uMVP");
        _modelLoc = GL.GetUniformLocation(_program, "uModel");
        _normalLoc = GL.GetUniformLocation(_program, "uNormalMat");
        _colorLoc = GL.GetUniformLocation(_program, "uColor");
        _camLoc = GL.GetUniformLocation(_program, "uCamPos");
        _pulseLoc = GL.GetUniformLocation(_program, "uPulse");
        _fogColorLoc = GL.GetUniformLocation(_program, "uFogColor");
        _fogDensityLoc = GL.GetUniformLocation(_program, "uFogDensity");
        _metallicLoc = GL.GetUniformLocation(_program, "uMetallic");
        _shininessLoc = GL.GetUniformLocation(_program, "uShininess");
        _opacityLoc = GL.GetUniformLocation(_program, "uOpacity");
        _emissiveLoc = GL.GetUniformLocation(_program, "uEmissive");
        _shadowMapLoc = GL.GetUniformLocation(_program, "uShadowMap");
        _lightVpLoc = GL.GetUniformLocation(_program, "uLightVP");
        _shadowsOnLoc = GL.GetUniformLocation(_program, "uShadowsOn");
        _shadowSizeLoc = GL.GetUniformLocation(_program, "uShadowSize");
        _shadowDistanceLoc = GL.GetUniformLocation(_program, "uShadowDistance");
        _sunDirLoc = GL.GetUniformLocation(_program, "uSunDir");
        _sunColorLoc = GL.GetUniformLocation(_program, "uSunColor");
        _sunILoc = GL.GetUniformLocation(_program, "uSunI");
        _ambientLoc = GL.GetUniformLocation(_program, "uAmbient");
        _reflectanceLoc = GL.GetUniformLocation(_program, "uReflectance");

        // One mesh per shape; the skybox reuses the Block VBO (position attribute only).
        foreach (ShapeKind shape in Enum.GetValues<ShapeKind>())
            _meshes[shape] = UploadMesh(MeshFactory.For(shape));

        _skyProgram = CreateProgram(SkyVertexSrc, SkyFragmentSrc);
        _skyMvpLoc = GL.GetUniformLocation(_skyProgram, "uMVP");
        _skySunDirLoc = GL.GetUniformLocation(_skyProgram, "uSunDir");
        _skySunTintLoc = GL.GetUniformLocation(_skyProgram, "uSunTint");
        _skySunILoc = GL.GetUniformLocation(_skyProgram, "uSunI");
        _skyHazeLoc = GL.GetUniformLocation(_skyProgram, "uHaze");
        _skyVao = GL.GenVertexArray();
        GL.BindVertexArray(_skyVao);
        GL.BindBuffer(BufferTarget.ArrayBuffer, _meshes[ShapeKind.Block].Vbo);
        int skyPos = GL.GetAttribLocation(_skyProgram, "vPosition");
        GL.EnableVertexAttribArray(skyPos);
        GL.VertexAttribPointer(skyPos, 3, VertexAttribPointerType.Float, false, Unsafe.SizeOf<Vertex>(), 0);
        GL.BindVertexArray(0);

        _decalProgram = CreateProgram(DecalVertexSrc, DecalFragmentSrc);
        _decalMvpLoc = GL.GetUniformLocation(_decalProgram, "uMVP");
        _decalImageLoc = GL.GetUniformLocation(_decalProgram, "uImage");
        _decalTransparencyLoc = GL.GetUniformLocation(_decalProgram, "uTransparency");
        _decalBlurLoc = GL.GetUniformLocation(_decalProgram, "uBlur");
        _decalVao = GL.GenVertexArray();
        _decalVbo = GL.GenBuffer();
        // position (local part space), UV; front-face vertices are updated per decal face.
        GL.BindVertexArray(_decalVao);
        GL.BindBuffer(BufferTarget.ArrayBuffer, _decalVbo);
        GL.BufferData(BufferTarget.ArrayBuffer, 6 * 5 * sizeof(float), IntPtr.Zero, BufferUsageHint.DynamicDraw);
        GL.EnableVertexAttribArray(0);
        GL.VertexAttribPointer(0, 3, VertexAttribPointerType.Float, false, 5 * sizeof(float), 0);
        GL.EnableVertexAttribArray(1);
        GL.VertexAttribPointer(1, 2, VertexAttribPointerType.Float, false, 5 * sizeof(float), 3 * sizeof(float));
        GL.BindVertexArray(0);

        // Move-gizmo arrows: small unlit shader + one arrow mesh per axis
        // (axis baked in at build time, so no runtime rotation convention risk).
        _gizmoProgram = CreateProgram(GizmoVertexSrc, GizmoFragmentSrc);
        _gizmoMvpLoc = GL.GetUniformLocation(_gizmoProgram, "uMVP");
        _gizmoColorLoc = GL.GetUniformLocation(_gizmoProgram, "uColor");
        var arrowTris = BuildArrowTris();
        UploadAxisMesh(arrowTris, _gizmoVaos, _gizmoVbos, _gizmoCounts);
        UploadAxisMesh(BuildScaleTris(), _scaleVaos, _scaleVbos, _scaleCounts);
        // Rotate rings: flat torus in the XZ plane permuted per axis (same trick).
        var ringTris = new List<Vector3>();
        foreach (var v in MeshFactory.Torus(0.65f, 0.03f, 48, 8)) ringTris.Add(v.Position);
        UploadAxisMesh(ringTris, _ringVaos, _ringVbos, _ringCounts);

        // Shadow map: depth texture + FBO, no color buffer.
        _depthProgram = CreateProgram(DepthVertexSrc, DepthFragmentSrc);
        _depthMvpLoc = GL.GetUniformLocation(_depthProgram, "uLightMVP");
        RecreateShadowTarget();

        GL.Enable(EnableCap.DepthTest);
        GL.Enable(EnableCap.Multisample); // MSAA resolve when the control allocates samples
        // All cube faces wind CCW from outside, so back faces can be culled.
        // (The skybox is viewed from inside and disables this during its pass.)
        GL.Enable(EnableCap.CullFace);
        GL.CullFace(TriangleFace.Back);
        GL.FrontFace(FrontFaceDirection.Ccw);

        if (Objects.Count == 0)
        {
            Objects.Add(new SceneObject
            {
                Name = "Baseplate", Shape = ShapeKind.Block,
                Position = new Vector3(0, -0.5f, 0), Size = new Vector3(32, 1, 32),
                Color = new Color4(0.64f, 0.635f, 0.647f, 1f),
                Anchored = true,
            });
            Objects.Add(new SceneObject
            {
                Name = "Part", Shape = ShapeKind.Block,
                Position = new Vector3(0, 1, 0), Size = new Vector3(2, 2, 2),
                Color = new Color4(0.25f, 0.55f, 0.95f, 1f), Material = MaterialKind.SmoothPlastic,
            });
            Objects.Add(new SceneObject
            {
                Name = "Ball", Shape = ShapeKind.Ball,
                Position = new Vector3(4.2f, 1, 0), Size = new Vector3(2, 2, 2),
                Color = new Color4(0.95f, 0.55f, 0.20f, 1f),
            });
            Objects.Add(new SceneObject
            {
                Name = "Pillar", Shape = ShapeKind.Cylinder,
                Position = new Vector3(-3.5f, 2f, 1.5f), Size = new Vector3(1, 4, 1),
                Color = new Color4(0.30f, 0.80f, 0.35f, 1f), Material = MaterialKind.Metal,
            });
            Objects.Add(new SceneObject
            {
                Name = "Wedge", Shape = ShapeKind.Wedge,
                Position = new Vector3(-4f, 1f, -2.5f), Size = new Vector3(2.5f, 2f, 2f),
                Color = new Color4(0.70f, 0.40f, 0.90f, 1f),
            });
            Objects.Add(new SceneObject
            {
                Name = "Cone", Shape = ShapeKind.Cone,
                Position = new Vector3(2.5f, 1.1f, 2.5f), Size = new Vector3(1.4f, 2.2f, 1.4f),
                Color = new Color4(0.95f, 0.30f, 0.45f, 1f), Material = MaterialKind.Neon,
            });
            Objects.Add(new SceneObject
            {
                Name = "Donut", Shape = ShapeKind.Torus,
                Position = new Vector3(-1f, 0.9f, -3f), Size = new Vector3(1.8f, 1.8f, 1.8f),
                Color = new Color4(0.25f, 0.85f, 0.85f, 1f), Material = MaterialKind.Glass,
            });
            Objects.Add(new SceneObject
            {
                Name = "Capsule", Shape = ShapeKind.Capsule,
                Position = new Vector3(-0.5f, 0.75f, 2.5f), Size = new Vector3(1.5f, 1.5f, 1.5f),
                Color = new Color4(0.95f, 0.80f, 0.25f, 1f),
            });
            Selected = Objects[1]; // the spinning Part, not the ground
        }
    }

    /// <summary>GLSL version baked into shaders at compile (460, or 400 on fallback hardware).</summary>
    public static int GlslVersion { get; set; } = 460;

    private int CreateProgram(string vs, string fs)
    {
        void Note(string msg)
        {
            InitLog += msg + "\n";
            Debug.WriteLine(msg);
        }

        // All sources are authored for 460 core but only use <= 4.0 constructs,
        // so fallback hardware just needs the version line retargeted.
        if (GlslVersion != 460)
        {
            string tag = "#version " + GlslVersion + " core";
            vs = vs.Replace("#version 460 core", tag);
            fs = fs.Replace("#version 460 core", tag);
        }

        int program = GL.CreateProgram();
        int v = GL.CreateShader(ShaderType.VertexShader);
        GL.ShaderSource(v, vs);
        GL.CompileShader(v);
        GL.GetShader(v, ShaderParameter.CompileStatus, out int ok);
        if (ok == 0) Note("VS error: " + GL.GetShaderInfoLog(v));

        int f = GL.CreateShader(ShaderType.FragmentShader);
        GL.ShaderSource(f, fs);
        GL.CompileShader(f);
        GL.GetShader(f, ShaderParameter.CompileStatus, out ok);
        if (ok == 0) Note("FS error: " + GL.GetShaderInfoLog(f));

        GL.AttachShader(program, v);
        GL.AttachShader(program, f);
        GL.LinkProgram(program);
        GL.GetProgram(program, GetProgramParameterName.LinkStatus, out ok);
        if (ok == 0) Note("Link error: " + GL.GetProgramInfoLog(program));

        GL.DetachShader(program, v);
        GL.DetachShader(program, f);
        GL.DeleteShader(v);
        GL.DeleteShader(f);
        return program;
    }

    /// <summary>Draw one part with its material. Caller sets program + shared uniforms.</summary>
    private void DrawObject(SceneObject o, Matrix4 view, Matrix4 proj, double now)
    {
        // Row-major: scale, then rotate in place, then translate.
        var model = ModelMatrix(o);
        var mvp = model * view * proj;
        GL.UniformMatrix4(_mvpLoc, false, ref mvp);
        GL.UniformMatrix4(_modelLoc, false, ref model);

        // Normal matrix for rotation + non-uniform scale: S^-1 * R
        // (inverse-transpose of the model's upper 3x3, row-major order).
        var normalMat =
            new Matrix3(
                1f / o.Size.X, 0, 0,
                0, 1f / o.Size.Y, 0,
                0, 0, 1f / o.Size.Z) *
            RotationPart(o);
        GL.UniformMatrix3(_normalLoc, false, ref normalMat);

        var mat = MaterialParams.Of(o.Material);
        GL.Uniform3(_colorLoc, new Vector3(o.Color.R, o.Color.G, o.Color.B));
        GL.Uniform1(_metallicLoc, mat.Metallic);
        GL.Uniform1(_shininessLoc, mat.Shininess);
        GL.Uniform1(_opacityLoc, mat.Opacity * (1f - o.Transparency));
        GL.Uniform1(_emissiveLoc, mat.Emissive);
        GL.Uniform1(_reflectanceLoc, Math.Clamp(o.Reflectance, 0f, 1f));

        // Selected object glows softly so the Explorer selection is visible.
        float pulse = ReferenceEquals(o, Selected)
            ? (0.22f + 0.10f * MathF.Sin((float)now * 6f)) * PulseStrength
            : 0f;
        GL.Uniform1(_pulseLoc, pulse);

        var mesh = _meshes[o.Shape];
        GL.BindVertexArray(mesh.Vao);
        GL.DrawArrays(PrimitiveType.Triangles, 0, mesh.Count);
    }

    private int GetDecalTexture(string path)
    {
        if (_decalTextures.TryGetValue(path, out int texture)) return texture;
        try
        {
            var image = ImageResult.FromMemory(File.ReadAllBytes(path), ColorComponents.RedGreenBlueAlpha);
            texture = GL.GenTexture();
            GL.BindTexture(TextureTarget.Texture2D, texture);
            GL.TexImage2D(TextureTarget.Texture2D, 0, PixelInternalFormat.Rgba8, image.Width, image.Height, 0,
                PixelFormat.Rgba, PixelType.UnsignedByte, image.Data);
            TrilinearSampling();
            GL.BindTexture(TextureTarget.Texture2D, 0);
            _decalTextures[path] = texture;
            return texture;
        }
        catch (Exception ex)
        {
            InitLog += $"Decal image failed ({path}): {ex.Message}\n";
            _decalTextures[path] = 0;
            return 0;
        }
    }

    /// <summary>Trilinear + mipmaps + aniso on the currently bound 2D texture.</summary>
    private static void TrilinearSampling()
    {
        // Decals/texts stay crisp at glancing angles / distance instead of shimmering.
        GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMinFilter, (int)TextureMinFilter.LinearMipmapLinear);
        GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMagFilter, (int)TextureMagFilter.Linear);
        GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureWrapS, (int)TextureWrapMode.ClampToEdge);
        GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureWrapT, (int)TextureWrapMode.ClampToEdge);
        GL.GenerateMipmap(GenerateMipmapTarget.Texture2D);
        try
        {
            GL.GetFloat((GetPName)0x84FF, out float maxAniso); // MAX_TEXTURE_MAX_ANISOTROPY_EXT
            if (maxAniso >= 2f)
                GL.TexParameter(TextureTarget.Texture2D, (TextureParameterName)0x84FE, Math.Min(8f, maxAniso));
        }
        catch { /* anisotropy is best-effort */ }
    }

    private int GetTextTexture(TextLayer t)
    {
        string key = $"{t.Text}\0{TextFonts.OrFallback(t.Font)}\0{Math.Clamp(t.Size, 8f, 256f):0.#}\0{t.Color}";
        if (_textTextures.TryGetValue(key, out int texture)) return texture;
        texture = RenderTextTexture(t);
        if (_textTextures.Count > 128) ClearTextTextures(); // unbounded typing guard
        _textTextures[key] = texture;
        return texture;
    }

    private void ClearTextTextures()
    {
        foreach (var texture in _textTextures.Values)
            if (texture != 0) GL.DeleteTexture(texture);
        _textTextures.Clear();
    }

    /// <summary>Rasterize a text layer with GDI+ (system fonts) into a GL texture. 0 on failure.</summary>
    private int RenderTextTexture(TextLayer t)
    {
        try
        {
            string text = string.IsNullOrEmpty(t.Text) ? " " : t.Text.Length > 200 ? t.Text[..200] : t.Text;
            if (!PartColor.TryParseRgb(t.Color, out var mc) && !PartColor.TryParseHex(t.Color, out mc))
                mc = System.Windows.Media.Color.FromRgb(255, 255, 255);
            float px = Math.Clamp(t.Size, 8f, 256f);
            using var font = new Gdi.Font(TextFonts.OrFallback(t.Font), px, Gdi.FontStyle.Regular, Gdi.GraphicsUnit.Pixel);
            int w, h;
            using (var measure = new Gdi.Bitmap(2, 2, GdiImaging.PixelFormat.Format32bppArgb))
            using (var mg = Gdi.Graphics.FromImage(measure))
            {
                var ms = mg.MeasureString(text, font, 1024);
                w = Math.Clamp((int)Math.Ceiling(ms.Width), 2, 1024);
                h = Math.Clamp((int)Math.Ceiling(ms.Height), 2, 1024);
            }
            using var bmp = new Gdi.Bitmap(w, h, GdiImaging.PixelFormat.Format32bppArgb);
            using (var g = Gdi.Graphics.FromImage(bmp))
            {
                g.Clear(Gdi.Color.Transparent);
                g.TextRenderingHint = GdiText.TextRenderingHint.AntiAlias;
                using var brush = new Gdi.SolidBrush(Gdi.Color.FromArgb(mc.R, mc.G, mc.B));
                using var format = new Gdi.StringFormat { Alignment = Gdi.StringAlignment.Center, LineAlignment = Gdi.StringAlignment.Center };
                g.DrawString(text, font, brush, new Gdi.RectangleF(0, 0, w, h), format);
            }
            var data = bmp.LockBits(new Gdi.Rectangle(0, 0, w, h), GdiImaging.ImageLockMode.ReadOnly, GdiImaging.PixelFormat.Format32bppArgb);
            try
            {
                int tex = GL.GenTexture();
                GL.BindTexture(TextureTarget.Texture2D, tex);
                // GDI memory is top-row-first BGRA: matches the decal UV convention as-is.
                GL.TexImage2D(TextureTarget.Texture2D, 0, PixelInternalFormat.Rgba8, w, h, 0,
                    PixelFormat.Bgra, PixelType.UnsignedByte, data.Scan0);
                TrilinearSampling();
                GL.BindTexture(TextureTarget.Texture2D, 0);
                return tex;
            }
            finally { bmp.UnlockBits(data); }
        }
        catch (Exception ex)
        {
            InitLog += $"Text render failed ({t.Text}): {ex.Message}\n";
            return 0;
        }
    }

    private void DrawDecal(SceneObject o, Matrix4 view, Matrix4 proj)
    {
        // Legacy single decal (pre-multi) + every list layer, then texts.
        // Each layer lifts slightly further off the face so same-face stacks don't z-fight.
        int lift = 0;
        if (!string.IsNullOrWhiteSpace(o.DecalImage))
            DrawDecalLayer(o, o.DecalImage, o.DecalFace, o.DecalTransparency, o.DecalBlur, view, proj, lift++, 0, 0, 1);
        foreach (var decal in o.Decals)
            DrawDecalLayer(o, decal.Image, decal.Face, decal.Transparency, decal.Blur, view, proj, lift++,
                decal.OffsetX, decal.OffsetY, decal.Scale);
        foreach (var text in o.Texts)
            DrawTextLayer(o, text, view, proj, lift++);
    }

    private void DrawDecalLayer(SceneObject o, string? imagePath, string face, float transparency, float blur, Matrix4 view, Matrix4 proj, int stackIndex, float offsetX, float offsetY, float scale)
    {
        if (string.IsNullOrWhiteSpace(imagePath)) return;
        int texture = GetDecalTexture(imagePath);
        if (texture == 0) return;
        DrawFaceQuad(o, texture, face, transparency, blur, offsetX, offsetY, scale, view, proj, stackIndex);
    }

    private void DrawTextLayer(SceneObject o, TextLayer t, Matrix4 view, Matrix4 proj, int stackIndex)
    {
        int texture = GetTextTexture(t);
        if (texture == 0) return;
        DrawFaceQuad(o, texture, t.Face, t.Transparency, t.Blur, t.OffsetX, t.OffsetY, t.Scale, view, proj, stackIndex);
    }

    private void DrawFaceQuad(SceneObject o, int texture, string face, float transparency, float blur, float offsetX, float offsetY, float scale, Matrix4 view, Matrix4 proj, int stackIndex)
    {
        if (texture == 0) return;
        // Stack lift: each layer floats a hair further off the surface so
        // same-face stacks never z-fight. Index 0 keeps the legacy 0.501.
        float p = 0.501f + Math.Max(stackIndex, 0) * 0.0015f;
        // Face-local frame (origin at UV 0,0; U right, V up). Matches the legacy
        // full-face winding exactly at offset 0 / scale 1.
        Vector3 O, U, V;
        switch (face)
        {
            case "Back":   O = new(.5f, -.5f, -p); U = new(-1f, 0, 0); V = new(0, 1f, 0); break;
            case "Left":   O = new(-p, -.5f, .5f); U = new(0, 0, -1f);  V = new(0, 1f, 0); break;
            case "Right":  O = new(p, -.5f, -.5f); U = new(0, 0, 1f);   V = new(0, 1f, 0); break;
            case "Top":    O = new(-.5f, p, .5f);  U = new(1f, 0, 0);   V = new(0, 0, -1f); break;
            case "Bottom": O = new(-.5f, -p, -.5f); U = new(1f, 0, 0);  V = new(0, 0, 1f); break;
            default:       O = new(-.5f, -.5f, p); U = new(1f, 0, 0);   V = new(0, 1f, 0); break; // Front
        }
        float s = Math.Clamp(scale <= 0 ? 1f : scale, 0.05f, 1f);
        float cu = 0.5f + Math.Clamp(offsetX, -1f, 1f);
        float cv = 0.5f + Math.Clamp(offsetY, -1f, 1f);
        float u0 = cu - s / 2f, u1 = cu + s / 2f;
        float v0 = cv - s / 2f, v1 = cv + s / 2f;
        Vector3 C(float uu, float vv) => O + U * Math.Clamp(uu, 0f, 1f) + V * Math.Clamp(vv, 0f, 1f);
        var a = C(u0, v0); var b = C(u1, v0); var c = C(u1, v1); var d = C(u0, v1);
        // UVs track the unclamped rect (edge sampler clamps); V flipped per convention.
        float[] v = { a.X,a.Y,a.Z,u0,1f-v0, b.X,b.Y,b.Z,u1,1f-v0, c.X,c.Y,c.Z,u1,1f-v1,
                      a.X,a.Y,a.Z,u0,1f-v0, c.X,c.Y,c.Z,u1,1f-v1, d.X,d.Y,d.Z,u0,1f-v1 };
        GL.BindBuffer(BufferTarget.ArrayBuffer, _decalVbo);
        GL.BufferSubData(BufferTarget.ArrayBuffer, IntPtr.Zero, v.Length * sizeof(float), v);
        GL.UseProgram(_decalProgram);
        // Decals belong to a part face, so they use the same transform as the
        // part and rotate with it.
        var mvp = ModelMatrix(o) * view * proj;
        GL.UniformMatrix4(_decalMvpLoc, false, ref mvp);
        GL.Uniform1(_decalTransparencyLoc, Math.Clamp(transparency, 0f, 1f));
        GL.Uniform1(_decalBlurLoc, Math.Clamp(blur, 0f, 1f));
        GL.ActiveTexture(TextureUnit.Texture1);
        GL.BindTexture(TextureTarget.Texture2D, texture);
        GL.Uniform1(_decalImageLoc, 1);
        GL.BindVertexArray(_decalVao);
        GL.DrawArrays(PrimitiveType.Triangles, 0, 6);
    }

    public void Render(int pixelWidth, int pixelHeight)
    {
        if (!_initialized || pixelWidth <= 0 || pixelHeight <= 0) return;
        long t0 = _clock.ElapsedTicks; // CPU submit time (GPU runs async behind this)

        double now = _clock.Elapsed.TotalSeconds;
        double dt = now - _lastTime;
        _lastTime = now;
        if (dt > 0) Fps = Fps * 0.95 + (1.0 / Math.Max(dt, 1e-4)) * 0.05;
        float h = Math.Clamp((float)dt, 0f, 0.05f); // clamp hitches so smoothing stays stable
        if (!PhysicsDriven)
            foreach (var o in Objects) o.ComposeOrientation();

        // Ease look toward its target (frame-rate independent).
        float lookT = 1f - MathF.Exp(-LookResponsiveness * h);
        _yaw += (_targetYaw - _yaw) * lookT;
        _pitch += (_targetPitch - _pitch) * lookT;
        if ((_targetYaw - _yaw) * (_targetYaw - _yaw) + (_targetPitch - _pitch) * (_targetPitch - _pitch) < 1e-10f)
        {
            _yaw = _targetYaw; // snap settled values so IsIdle goes exactly true
            _pitch = _targetPitch;
        }

        // Ramp fly velocity toward desired (smooth starts/stops), then integrate.
        var desired = (Forward * FlyInput.Z + Right * FlyInput.X + Vector3.UnitY * FlyInput.Y)
                      * MoveSpeed * (FlySlow ? SlowMultiplier : 1f);
        float moveT = 1f - MathF.Exp(-MoveResponsiveness * h);
        _flyVel += (desired - _flyVel) * moveT;
        if (_flyVel.LengthSquared < 1e-10f) _flyVel = Vector3.Zero;
        Position += _flyVel * h;

        // Decay the wheel-zoom impulse and integrate, keeping out of the cube.
        if (_zoomVel != 0f)
        {
            var next = Position + Forward * (_zoomVel * h);
            if (next.Length < 1.5f || next.Length > 200f)
            {
                next = Position;
                _zoomVel = 0f;
            }
            Position = next;
            _zoomVel *= MathF.Exp(-ZoomDecay * h);
            if (MathF.Abs(_zoomVel) < 0.01f) _zoomVel = 0f;
        }

        // Roblox-style follow: the orbit angles (yaw/pitch) + wheel distance sit
        // rigidly on the avatar (no trailing offset). Runs before the view matrix
        // so there is zero frame lag. A cheap floor slide keeps the camera out of
        // the ground (no full camera collision yet).
        if (PhysicsDriven && FollowTarget != null)
        {
            _targetPitch = Math.Clamp(_targetPitch, -75f, 80f);
            _pitch = Math.Clamp(_pitch, -75f, 80f);
            var focus = FollowTarget.Position + new Vector3(0, FollowHeight, 0);
            var wantPos = focus - Forward * FollowDistance;
            if (wantPos.Y < 0.25f && focus.Y > 0.25f)
            {
                float a = (focus.Y - 0.25f) / (focus.Y - wantPos.Y);
                wantPos = focus + (wantPos - focus) * Math.Clamp(a, 0.05f, 1f);
            }
            Position = wantPos;
        }

        GL.Viewport(0, 0, pixelWidth, pixelHeight);
        GL.ClearColor(FogColor.X, FogColor.Y, FogColor.Z, 1f);
        GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);

        var view = Matrix4.LookAt(Position, Position + Forward, Vector3.UnitY);
        var proj = Matrix4.CreatePerspectiveFieldOfView(
            MathHelper.DegreesToRadians(FovDeg), pixelWidth / (float)pixelHeight, 0.1f, 500f);

        // Sun depth prepass into the shadow map (skipped when toggled off).
        // Follow frustum: the shadow box (half-extent = ShadowDistance) travels
        // with the action (avatar in play, selection — or view focus — in edit)
        // so distant objects keep shadows at full resolution. The focus snaps to
        // the texel grid so the traveling box doesn't shimmer shadow edges; a
        // cell change re-renders the cached map.
        Vector3 wantFocus = (PhysicsDriven && FollowTarget != null) ? FollowTarget.Position
            : Selected != null ? Selected.Position
            : Position + Forward * 12f;
        {
            float texel = 2f * ShadowDistance / ShadowMapSize;
            var side = Vector3.Normalize(Vector3.Cross(SunDirection, Vector3.UnitY));
            var up2 = Vector3.Normalize(Vector3.Cross(side, SunDirection));
            wantFocus += side * (MathF.Round(Vector3.Dot(wantFocus, side) / texel) * texel - Vector3.Dot(wantFocus, side))
                       + up2 * (MathF.Round(Vector3.Dot(wantFocus, up2) / texel) * texel - Vector3.Dot(wantFocus, up2));
        }
        if ((wantFocus - _lastShadowFocus).LengthSquared > 1e-10f)
        {
            _lastShadowFocus = wantFocus;
            InvalidateShadows();
        }
        var lightDist = 40f + ShadowDistance;
        var lightView = Matrix4.LookAt(wantFocus + SunDirection * lightDist, wantFocus, Vector3.UnitY);
        var lightProj = Matrix4.CreateOrthographicOffCenter(
            -ShadowDistance, ShadowDistance, -ShadowDistance, ShadowDistance, 1f, 80f + 4f * ShadowDistance);
        var lightVp = lightView * lightProj;
        // Cached: re-render depth only when parts move/change or the follow
        // focus hops a texel cell (plain camera motion stays free otherwise).
        if (WantedShadowSize() != ShadowMapSize) RecreateShadowTarget();
        if (ShadowsEnabled && _shadowDirty)
        {
            int prevFbo = GL.GetInteger(GetPName.FramebufferBinding);
            GL.BindFramebuffer(FramebufferTarget.Framebuffer, _shadowFbo);
            GL.Viewport(0, 0, ShadowMapSize, ShadowMapSize);
            GL.Clear(ClearBufferMask.DepthBufferBit);
            GL.UseProgram(_depthProgram);
            // Push caster depth slightly away from the receiver to prevent
            // precision noise from shadowing the caster's own surface.
            GL.Enable(EnableCap.PolygonOffsetFill);
            GL.PolygonOffset(1.5f, 2.0f);
            // Default back-face culling: front faces land in the map, keeping
            // contacts tight (back faces + big bias detached the shadows).
            foreach (var o in Objects)
            {
                if (MaterialParams.Of(o.Material).Transparent) continue; // glass casts none
                if (o.Transparency >= 0.99f) continue; // effectively invisible casts none
                if (!o.CastShadow) continue; // per-part opt-out (still receives)
                var lm = ModelMatrix(o) * lightVp;
                GL.UniformMatrix4(_depthMvpLoc, false, ref lm);
                var mesh = _meshes[o.Shape];
                GL.BindVertexArray(mesh.Vao);
                GL.DrawArrays(PrimitiveType.Triangles, 0, mesh.Count);
            }
            GL.Disable(EnableCap.PolygonOffsetFill);
            GL.BindFramebuffer(FramebufferTarget.Framebuffer, prevFbo);
            GL.Viewport(0, 0, pixelWidth, pixelHeight);
            _shadowDirty = false;
        }

        // Skybox first, centered on the camera. No depth writes, no culling
        // (seen from inside), so cubes always draw over it regardless of distance.
        GL.DepthMask(false);
        GL.Disable(EnableCap.CullFace);
        GL.UseProgram(_skyProgram);
        var skyModel = Matrix4.CreateScale(SkyHalf) * Matrix4.CreateTranslation(Position);
        var skyMvp = skyModel * view * proj;
        GL.UniformMatrix4(_skyMvpLoc, false, ref skyMvp);
        GL.Uniform3(_skySunDirLoc, SunDirection);
        GL.Uniform3(_skySunTintLoc, SunColor);
        GL.Uniform1(_skySunILoc, SunIntensity);
        GL.Uniform1(_skyHazeLoc, SkyHaze);
        GL.BindVertexArray(_skyVao);
        GL.DrawArrays(PrimitiveType.Triangles, 0, 36);
        GL.Enable(EnableCap.CullFace);
        GL.DepthMask(true);

        GL.UseProgram(_program);
        GL.Uniform3(_fogColorLoc, FogColor);
        GL.Uniform3(_sunDirLoc, SunDirection);
        GL.Uniform3(_sunColorLoc, SunColor);
        GL.Uniform1(_sunILoc, SunIntensity);
        GL.Uniform1(_ambientLoc, AmbientBoost);
        GL.Uniform1(_fogDensityLoc, FogDensity);
        GL.Uniform3(_camLoc, Position);
        GL.ActiveTexture(TextureUnit.Texture0);
        GL.BindTexture(TextureTarget.Texture2D, _shadowTex);
        GL.Uniform1(_shadowMapLoc, 0);
        GL.UniformMatrix4(_lightVpLoc, false, ref lightVp);
        GL.Uniform1(_shadowsOnLoc, ShadowsEnabled ? 1f : 0f);
        GL.Uniform1(_shadowSizeLoc, (float)ShadowMapSize);
        GL.Uniform1(_shadowDistanceLoc, ShadowDistance);

        // Opaque pass, then transparents far-to-near (insertion-sorted, no allocs).
        // Anything with effective transparency joins the sorted pass.
        _transparent.Clear();
        foreach (var o in Objects)
        {
            if (MaterialParams.Of(o.Material).Transparent || o.Transparency > 0.001f)
            {
                float key = (o.Position - Position).LengthSquared;
                int at = _transparent.Count;
                while (at > 0 && ( _transparent[at - 1].Position - Position).LengthSquared < key)
                    at--;
                _transparent.Insert(at, o);
            }
            else DrawObject(o, view, proj, now);
        }
        GL.DepthMask(false); // transparents test depth but don't write it
        GL.Enable(EnableCap.Blend); // without this the alpha channel is ignored
        GL.BlendFunc(BlendingFactor.SrcAlpha, BlendingFactor.OneMinusSrcAlpha);
        foreach (var o in _transparent) DrawObject(o, view, proj, now);
        GL.Disable(EnableCap.Blend);
        GL.DepthMask(true);
        GL.BindVertexArray(0);

        // Edit-mode spawn markers: bobbing neon dots above Spawn parts
        // (plain lit ball, no scene membership, casts no shadow).
        if (!PhysicsDriven)
        {
            GL.UseProgram(_program);
            float bob = 0.15f * MathF.Sin((float)now * 3f);
            var markerNormal = Matrix3.Identity;
            foreach (var o in Objects)
            {
                if (!o.IsSpawn) continue;
                var mPos = o.Position + Vector3.Transform(
                    new Vector3(0, o.Size.Y * 0.5f + 0.6f + bob, 0), o.Orientation);
                var model = Matrix4.CreateScale(0.4f) * Matrix4.CreateTranslation(mPos);
                var mvp = model * view * proj;
                GL.UniformMatrix4(_mvpLoc, false, ref mvp);
                GL.UniformMatrix4(_modelLoc, false, ref model);
                GL.UniformMatrix3(_normalLoc, false, ref markerNormal);
                GL.Uniform3(_colorLoc, new Vector3(0.3f, 1f, 0.4f));
                GL.Uniform1(_metallicLoc, 0f);
                GL.Uniform1(_shininessLoc, 32f);
                GL.Uniform1(_opacityLoc, 1f);
                GL.Uniform1(_emissiveLoc, 1.5f);
                GL.Uniform1(_pulseLoc, 0f);
                var markerMesh = _meshes[ShapeKind.Ball];
                GL.BindVertexArray(markerMesh.Vao);
                GL.DrawArrays(PrimitiveType.Triangles, 0, markerMesh.Count);
            }
            GL.BindVertexArray(0);
        }

        // Decals are independent textured overlays, projected onto the chosen
        // local part face just above its surface to avoid z-fighting.
        GL.Enable(EnableCap.Blend);
        GL.BlendFunc(BlendingFactor.SrcAlpha, BlendingFactor.OneMinusSrcAlpha);
        GL.Disable(EnableCap.CullFace);
        GL.DepthMask(false);
        foreach (var o in Objects) DrawDecal(o, view, proj);
        GL.DepthMask(true);
        GL.Disable(EnableCap.Blend);
        GL.Enable(EnableCap.CullFace);

        // Active tool's gizmo: constant screen size, drawn last without depth/culling (always on top).
        if (Selected != null && ActiveGizmo != GizmoKind.None)
        {
            var vaos = ActiveGizmo == GizmoKind.Scale ? _scaleVaos
                     : ActiveGizmo == GizmoKind.Rotate ? _ringVaos : _gizmoVaos;
            var counts = ActiveGizmo == GizmoKind.Scale ? _scaleCounts
                       : ActiveGizmo == GizmoKind.Rotate ? _ringCounts : _gizmoCounts;
            float gs = GizmoScale(pixelHeight);
            GL.Disable(EnableCap.DepthTest);
            GL.Disable(EnableCap.CullFace);
            GL.UseProgram(_gizmoProgram);
            // Arrows and scale boxes draw mirrored too (both axis ends, Studio-style);
            // rings already surround fully. Mirroring flips winding, which is fine here.
            // Handles follow the selection's orientation (local axes, like Roblox).
            var grot = Matrix4.CreateFromQuaternion(Selected.Orientation);
            int sides = ActiveGizmo == GizmoKind.Rotate ? 1 : 2;
            for (int a = 0; a < 3; a++)
            {
                // Hovered handle goes yellow, dragged handle pale yellow; else axis color.
                Vector3 col = a == ActiveAxis ? new Vector3(1.0f, 0.95f, 0.45f)
                            : a == HoverAxis ? new Vector3(1.0f, 0.78f, 0.08f)
                            : AxisColors[a];
                GL.Uniform3(_gizmoColorLoc, col);
                GL.BindVertexArray(vaos[a]);
                for (int side = 0; side < sides; side++)
                {
                    Vector3 sc = a == 0 ? new Vector3(side == 0 ? gs : -gs, gs, gs)
                               : a == 1 ? new Vector3(gs, side == 0 ? gs : -gs, gs)
                               : new Vector3(gs, gs, side == 0 ? gs : -gs);
                    var m = Matrix4.CreateScale(sc) * grot * Matrix4.CreateTranslation(Selected.Position);
                    var gm = m * view * proj;
                    GL.UniformMatrix4(_gizmoMvpLoc, false, ref gm);
                    GL.DrawArrays(PrimitiveType.Triangles, 0, (int)counts[a]);
                }
            }
            GL.BindVertexArray(0);
            GL.Enable(EnableCap.CullFace);
            GL.Enable(EnableCap.DepthTest);
        }

        double cpuMs = (double)(_clock.ElapsedTicks - t0) * 1000.0 / Stopwatch.Frequency;
        CpuMs = CpuMs * 0.95 + cpuMs * 0.05;
    }

    /// <summary>
    /// True when a frame would look identical to the last: nothing selected
    /// (no pulse), camera fully settled, no fly input. Lets the UI skip GL work.
    /// </summary>
    public bool IsIdle =>
        Selected == null &&
        _flyVel == Vector3.Zero &&
        _zoomVel == 0f &&
        _yaw == _targetYaw && _pitch == _targetPitch &&
        FlyInput == Vector3.Zero;

    // ---------- picking + gizmo math (all world units, camera-independent of DPI) ----------

    /// <summary>Constant on-screen gizmo size (~110 px tall at any distance).</summary>
    public float GizmoScale(float viewportHeightPx)
    {
        if (Selected == null || viewportHeightPx <= 0) return 0;
        float dist = Math.Max((Selected.Position - Position).Length, 0.001f);
        return dist * 2f * MathF.Tan(MathHelper.DegreesToRadians(FovDeg / 2f)) * (110f / viewportHeightPx);
    }

    public void GetPickRay(float mx, float my, float w, float h, out Vector3 origin, out Vector3 dir)
    {
        float nx = mx / w * 2f - 1f;
        float ny = 1f - my / h * 2f;
        var view = Matrix4.LookAt(Position, Position + Forward, Vector3.UnitY);
        var proj = Matrix4.CreatePerspectiveFieldOfView(
            MathHelper.DegreesToRadians(FovDeg), w / h, 0.1f, 100f);
        var inv = (view * proj).Inverted();
        var near = new Vector4(nx, ny, -1f, 1f) * inv;
        var far = new Vector4(nx, ny, 1f, 1f) * inv;
        near /= near.W;
        far /= far.W;
        origin = Position;
        dir = Vector3.Normalize(new Vector3(far.X - Position.X, far.Y - Position.Y, far.Z - Position.Z));
    }

    /// <summary>Nearest object under the cursor, or null. Exact per-shape tests, world-unit t.</summary>
    public SceneObject? Pick(float mx, float my, float w, float h)
    {
        if (w <= 0 || h <= 0) return null;
        GetPickRay(mx, my, w, h, out var origin, out var dir);
        SceneObject? best = null;
        float bestT = float.MaxValue;
        foreach (var o in Objects)
        {
            if (o.IsAvatarFace) continue; // managed face panel: click through to the avatar
            // World -> object-local via the transpose of the render rotation (exact inverse).
            var rot = RotationPart(o);
            Vector3 rel = origin - o.Position;
            Vector3 lo = new(
                rel.X * rot.M11 + rel.Y * rot.M21 + rel.Z * rot.M31,
                rel.X * rot.M12 + rel.Y * rot.M22 + rel.Z * rot.M32,
                rel.X * rot.M13 + rel.Y * rot.M23 + rel.Z * rot.M33);
            Vector3 ld = new(
                dir.X * rot.M11 + dir.Y * rot.M21 + dir.Z * rot.M31,
                dir.X * rot.M12 + dir.Y * rot.M22 + dir.Z * rot.M32,
                dir.X * rot.M13 + dir.Y * rot.M23 + dir.Z * rot.M33);
            // Strip scale -> unit-shape space, solve, then measure world t from the hit.
            Vector3 lu = Div(lo, o.Size);
            Vector3 du = Div(ld, o.Size);
            float tl;
            bool hit = o.Shape switch
            {
                ShapeKind.Ball => RaySphere(lu, du, 0.5f, out tl),
                ShapeKind.Cylinder => RayCylinder(lu, du, out tl),
                ShapeKind.Wedge => RayWedge(lu, du, out tl),
                ShapeKind.Cone => RayCone(lu, du, out tl),
                ShapeKind.Capsule => RayCapsule(lu, du, out tl),
                _ => RaySlab(lu, du, new Vector3(0.5f, 0.5f, 0.5f), out tl), // Block + Torus bbox
            };
            if (!hit || tl <= 0) continue;
            var model = ModelMatrix(o);
            Vector3 worldHit = Vector3.TransformPosition(lu + du * tl, model);
            float tw = (worldHit - origin).Length;
            if (tw < bestT)
            {
                bestT = tw;
                best = o;
            }
        }
        return best;
    }

    private static Vector3 Div(Vector3 a, Vector3 b) => new(
        a.X / Math.Max(b.X, 1e-4f), a.Y / Math.Max(b.Y, 1e-4f), a.Z / Math.Max(b.Z, 1e-4f));

    private static Matrix4 ModelMatrix(SceneObject o)
    {
        return Matrix4.CreateScale(o.Size) *
               Matrix4.CreateFromQuaternion(o.Orientation) *
               Matrix4.CreateTranslation(o.Position);
    }

    private static Matrix3 RotationPart(SceneObject o) =>
        Matrix3.CreateFromQuaternion(o.Orientation);

    private static bool RaySphere(Vector3 o, Vector3 d, float r, out float t)
    {
        float a = Vector3.Dot(d, d);
        float b = Vector3.Dot(o, d);
        float c = Vector3.Dot(o, o) - r * r;
        t = 0;
        if (a < 1e-12f) return false;
        float disc = b * b - a * c;
        if (disc < 0) return false;
        float sq = MathF.Sqrt(disc);
        float t0 = (-b - sq) / a;
        if (t0 > 1e-4f) { t = t0; return true; }
        float t1 = (-b + sq) / a;
        if (t1 > 1e-4f) { t = t1; return true; } // origin inside
        return false;
    }

    private static bool RayCylinder(Vector3 o, Vector3 d, out float t)
    {
        const float r = 0.5f;
        float best = float.MaxValue;
        bool found = false;
        void Consider(float tc, float y)
        {
            if (tc > 1e-4f && y >= -0.5f && y <= 0.5f && tc < best) { best = tc; found = true; }
        }
        float a = d.X * d.X + d.Z * d.Z;
        if (a > 1e-12f)
        {
            float b = o.X * d.X + o.Z * d.Z;
            float c = o.X * o.X + o.Z * o.Z - r * r;
            float disc = b * b - a * c;
            if (disc >= 0)
            {
                float sq = MathF.Sqrt(disc);
                float t0 = (-b - sq) / a;
                Consider(t0, o.Y + t0 * d.Y);
                float t1 = (-b + sq) / a;
                Consider(t1, o.Y + t1 * d.Y);
            }
        }
        if (MathF.Abs(d.Y) > 1e-8f)
        {
            foreach (float yc in new[] { -0.5f, 0.5f })
            {
                float tc = (yc - o.Y) / d.Y;
                float x = o.X + tc * d.X, z = o.Z + tc * d.Z;
                if (tc > 1e-4f && x * x + z * z <= r * r && tc < best) { best = tc; found = true; }
            }
        }
        t = found ? best : 0;
        return found;
    }

    private static bool RayCone(Vector3 o, Vector3 d, out float t)
    {
        float best = float.MaxValue;
        bool found = false;
        void Consider(float tc)
        {
            if (tc <= 1e-4f || tc >= best) return;
            float y = o.Y + tc * d.Y;
            if (y >= -0.5f && y <= 0.5f) { best = tc; found = true; }
        }
        // |o.xz + t d.xz| = 0.5 * (0.5 - (o.y + t d.y)): apex (0,+.5,0), base r=.5 at y=-.5.
        float k = 0.5f - o.Y;
        float a = d.X * d.X + d.Z * d.Z - 0.25f * d.Y * d.Y;
        float b = 2f * (o.X * d.X + o.Z * d.Z) + 0.5f * k * d.Y;
        float c = o.X * o.X + o.Z * o.Z - 0.25f * k * k;
        if (MathF.Abs(a) < 1e-12f)
        {
            if (MathF.Abs(b) > 1e-12f) Consider(-c / b);
        }
        else
        {
            float disc = b * b - 4f * a * c;
            if (disc >= 0)
            {
                float sq = MathF.Sqrt(disc);
                Consider((-b - sq) / (2f * a));
                Consider((-b + sq) / (2f * a));
            }
        }
        if (MathF.Abs(d.Y) > 1e-8f) // base cap
        {
            float tc = (-0.5f - o.Y) / d.Y;
            float x = o.X + tc * d.X, z = o.Z + tc * d.Z;
            if (tc > 1e-4f && x * x + z * z <= 0.25f && tc < best) { best = tc; found = true; }
        }
        t = found ? best : 0;
        return found;
    }

    /// <summary>Unit capsule: cylinder (|y| &lt;= .25, r = .25) + hemispheres at y = ±.25.</summary>
    private static bool RayCapsule(Vector3 o, Vector3 d, out float t)
    {
        const float r = 0.25f;
        float best = float.MaxValue;
        bool found = false;
        void Consider(float tc) { if (tc > 1e-4f && tc < best) { best = tc; found = true; } }
        float a = d.X * d.X + d.Z * d.Z;
        if (a > 1e-12f)
        {
            float b = o.X * d.X + o.Z * d.Z;
            float c = o.X * o.X + o.Z * o.Z - r * r;
            float disc = b * b - a * c;
            if (disc >= 0)
            {
                float sq = MathF.Sqrt(disc);
                float t0 = (-b - sq) / a;
                if (t0 > 1e-4f && Math.Abs(o.Y + t0 * d.Y) <= 0.25f) Consider(t0);
                float t1 = (-b + sq) / a;
                if (t1 > 1e-4f && Math.Abs(o.Y + t1 * d.Y) <= 0.25f) Consider(t1);
            }
        }
        if (RaySphere(o - new Vector3(0, 0.25f, 0), d, r, out float tt)) Consider(tt);
        if (RaySphere(o - new Vector3(0, -0.25f, 0), d, r, out tt)) Consider(tt);
        t = found ? best : 0;
        return found;
    }

    private static bool RayWedge(Vector3 o, Vector3 d, out float t)    {
        // Unit wedge: |x|,|y| <= .5, z >= -.5, y + z <= 0. Clip the ray against its planes.
        float best = float.MaxValue;
        bool found = false;
        if (InsideWedge(o)) { t = 0f; return true; }
        void Hit(float tc)
        {
            if (tc <= 1e-4f || tc >= best) return;
            if (InsideWedge(o + d * tc, 1e-3f)) { best = tc; found = true; }
        }
        if (MathF.Abs(d.X) > 1e-8f) { Hit((-0.5f - o.X) / d.X); Hit((0.5f - o.X) / d.X); }
        if (MathF.Abs(d.Y) > 1e-8f) { Hit((-0.5f - o.Y) / d.Y); Hit((0.5f - o.Y) / d.Y); }
        if (MathF.Abs(d.Z) > 1e-8f) { Hit((-0.5f - o.Z) / d.Z); }
        float ds = d.Y + d.Z; // slope plane y + z = 0
        if (MathF.Abs(ds) > 1e-8f) { Hit(-(o.Y + o.Z) / ds); }
        t = found ? best : 0;
        return found;
    }

    private static bool InsideWedge(Vector3 p, float tol = 0f) =>
        p.X >= -0.5f - tol && p.X <= 0.5f + tol &&
        p.Y >= -0.5f - tol && p.Y <= 0.5f + tol &&
        p.Z >= -0.5f - tol && p.Y + p.Z <= tol;

    private static bool RaySlab(Vector3 o, Vector3 d, Vector3 half, out float t)
    {
        t = 0f;
        float tmax = float.MaxValue;
        return Slab(o.X, d.X, -half.X, half.X, ref t, ref tmax)
            && Slab(o.Y, d.Y, -half.Y, half.Y, ref t, ref tmax)
            && Slab(o.Z, d.Z, -half.Z, half.Z, ref t, ref tmax);
    }

    private static bool Slab(float o, float d, float mn, float mx, ref float t0, ref float t1)
    {
        if (MathF.Abs(d) < 1e-8f) return o >= mn && o <= mx;
        float tA = (mn - o) / d;
        float tB = (mx - o) / d;
        if (tA > tB) (tA, tB) = (tB, tA);
        t0 = Math.Max(t0, tA);
        t1 = Math.Min(t1, tB);
        return t0 <= t1;
    }

    private static readonly Vector3[] AxisColors =
    {
        new(0.90f, 0.22f, 0.22f), // X red
        new(0.28f, 0.85f, 0.32f), // Y green
        new(0.30f, 0.52f, 0.95f), // Z blue
    };

    /// <summary>Arrow under the cursor (0=X, 1=Y, 2=Z) or -1. fbH = framebuffer height px.</summary>
    public int PickGizmoAxis(float mx, float my, float w, float h, float fbH)
    {
        if (Selected == null || w <= 0 || h <= 0) return -1;
        GetPickRay(mx, my, w, h, out var ro, out var rd);
        float gs = GizmoScale(fbH);
        float thresh = Math.Max((Selected.Position - Position).Length * 0.035f, 0.001f);
        int best = -1;
        float bestD = thresh;
        for (int a = 0; a < 3; a++)
        {
            if (!AxisClosest(GizmoAxis(a), ro, rd, out float axisT, out float rayT, out float dist))
                continue;
            if (rayT < 0 || Math.Abs(axisT) > 1.05f * gs || dist >= bestD)
                continue;
            bestD = dist;
            best = a;
        }
        return best;
    }

    /// <summary>
    /// Ring under the cursor (0=X, 1=Y, 2=Z) or -1, plus the plane hit point
    /// (for starting a drag). Ring radius is 0.65 in gizmo units; the grab band
    /// is deliberately generous (~30 px) for easy dragging.
    /// </summary>
    public int PickRingAxis(float mx, float my, float w, float h, float fbH, out Vector3 ringPoint)
    {
        ringPoint = Vector3.Zero;
        if (Selected == null || w <= 0 || h <= 0) return -1;
        GetPickRay(mx, my, w, h, out var ro, out var rd);
        float gs = GizmoScale(fbH);
        if (gs <= 0) return -1;
        float thresh = gs * 0.3f;
        int best = -1;
        float bestD = thresh;
        for (int a = 0; a < 3; a++)
        {
            var u = GizmoAxis(a);
            float denom = Vector3.Dot(rd, u);
            if (MathF.Abs(denom) < 1e-6f) continue; // looking edge-on at this ring
            float t = Vector3.Dot(Selected.Position - ro, u) / denom;
            if (t < 0) continue;
            var p = ro + rd * t;
            float radial = (p - Selected.Position).Length;
            float d = Math.Abs(radial - 0.65f * gs);
            if (d < bestD)
            {
                bestD = d;
                best = a;
                ringPoint = p;
            }
        }
        return best;
    }

    /// <summary>Closest point on the (infinite) axis line through the selection to a ray.</summary>
    public Vector3 AxisPoint(int axis, Vector3 rayOrigin, Vector3 rayDir)
    {
        var o = Selected?.Position ?? Vector3.Zero;
        var u = GizmoAxis(axis);
        if (!AxisClosest(u, rayOrigin, rayDir, out float axisT, out _, out _))
            return o;
        return o + u * axisT;
    }

    private bool AxisClosest(Vector3 u, Vector3 ro, Vector3 rd, out float axisT, out float rayT, out float dist)
    {
        var o = Selected?.Position ?? Vector3.Zero;
        Vector3 w0 = o - ro;
        float b = Vector3.Dot(rd, u);
        float d = Vector3.Dot(u, w0);
        float e = Vector3.Dot(rd, w0);
        float denom = 1f - b * b;
        axisT = 0;
        rayT = 0;
        dist = 0;
        if (MathF.Abs(denom) < 1e-6f) return false; // looking straight down the axis
        axisT = (b * e - d) / denom;
        rayT = (e - b * d) / denom;
        dist = (o + u * axisT - (ro + rd * rayT)).Length;
        return true;
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        try
        {
            foreach (var mesh in _meshes.Values)
            {
                if (mesh.Vbo != 0) GL.DeleteBuffer(mesh.Vbo);
                if (mesh.Vao != 0) GL.DeleteVertexArray(mesh.Vao);
            }
            if (_skyVao != 0) GL.DeleteVertexArray(_skyVao);
            if (_program != 0) GL.DeleteProgram(_program);
            if (_skyProgram != 0) GL.DeleteProgram(_skyProgram);
            if (_decalProgram != 0) GL.DeleteProgram(_decalProgram);
            if (_decalVbo != 0) GL.DeleteBuffer(_decalVbo);
            if (_decalVao != 0) GL.DeleteVertexArray(_decalVao);
            foreach (var texture in _decalTextures.Values)
                if (texture != 0) GL.DeleteTexture(texture);
            foreach (var texture in _textTextures.Values)
                if (texture != 0) GL.DeleteTexture(texture);
            if (_gizmoProgram != 0) GL.DeleteProgram(_gizmoProgram);
            if (_depthProgram != 0) GL.DeleteProgram(_depthProgram);
            if (_shadowTex != 0) GL.DeleteTexture(_shadowTex);
            if (_shadowFbo != 0) GL.DeleteFramebuffer(_shadowFbo);
            for (int a = 0; a < 3; a++)
            {
                if (_gizmoVbos[a] != 0) GL.DeleteBuffer(_gizmoVbos[a]);
                if (_gizmoVaos[a] != 0) GL.DeleteVertexArray(_gizmoVaos[a]);
                if (_scaleVbos[a] != 0) GL.DeleteBuffer(_scaleVbos[a]);
                if (_scaleVaos[a] != 0) GL.DeleteVertexArray(_scaleVaos[a]);
                if (_ringVbos[a] != 0) GL.DeleteBuffer(_ringVbos[a]);
                if (_ringVaos[a] != 0) GL.DeleteVertexArray(_ringVaos[a]);
            }
        }
        catch { /* context may be gone */ }
    }
}
