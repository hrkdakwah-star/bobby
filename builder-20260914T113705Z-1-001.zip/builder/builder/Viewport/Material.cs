namespace builder.Viewport;

/// <summary>Named surface presets. Real shader params, not just tints.</summary>
public enum MaterialKind
{
    Plastic,
    SmoothPlastic,
    Metal,
    Glass,
    Neon,
}

public readonly struct MaterialParams
{
    public readonly float Shininess;
    public readonly float Metallic;
    public readonly float Opacity;
    public readonly float Emissive;
    public readonly string Blurb;

    private MaterialParams(float shininess, float metallic, float opacity, float emissive, string blurb)
    {
        Shininess = shininess;
        Metallic = metallic;
        Opacity = opacity;
        Emissive = emissive;
        Blurb = blurb;
    }

    public bool Transparent => Opacity < 0.999f;

    public static MaterialParams Of(MaterialKind kind) => kind switch
    {
        MaterialKind.SmoothPlastic => new(64f, 0f, 1f, 0f, "Glossy highlights"),
        MaterialKind.Metal => new(90f, 1f, 1f, 0f, "Tinted specular, dark diffuse"),
        MaterialKind.Glass => new(120f, 0f, 0.30f, 0f, "See-through, sorted back-to-front"),
        MaterialKind.Neon => new(32f, 0f, 1f, 1.4f, "Self-lit glow"),
        _ => new(24f, 0f, 1f, 0f, "Matte everyday plastic"),
    };
}
