﻿using System;
using System.Threading.Tasks;
using System.Windows;
using builder.Settings;
using ControlzEx.Theming;

namespace builder
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            CrashLog.Startup("OnStartup begin");
            AppDomain.CurrentDomain.UnhandledException += (_, a) =>
                CrashLog.Crash("FATAL domain", a.ExceptionObject);
            DispatcherUnhandledException += (_, a) =>
            {
                CrashLog.Crash("FATAL ui", a.Exception);
                MessageBox.Show("builder crashed:\n" + a.Exception.Message +
                    "\n\nDetails in %AppData%\\BuilderStudio\\crash.log",
                    "builder engine", MessageBoxButton.OK, MessageBoxImage.Error);
            };
            TaskScheduler.UnobservedTaskException += (_, a) =>
            {
                CrashLog.Crash("FATAL task", a.Exception);
                a.SetObserved();
            };
            // Roblox-Studio-like dark ribbon. Base colors: Dark/Light, accents: Blue, Cobalt, etc.
            // Generated at runtime by ControlzEx (Fluent.Ribbon 8+ moved ThemeManager there).
            AppSettings.Current = AppSettings.Load();
            CrashLog.Startup("settings loaded");
            ThemeManager.Current.ChangeTheme(this, AppSettings.Current.DarkTheme ? "Dark.Cobalt" : "Light.Cobalt");
            CrashLog.Startup("theme set");
            base.OnStartup(e); // creates MainWindow via StartupUri
            CrashLog.Startup("base.OnStartup returned");
        }
    }
}
