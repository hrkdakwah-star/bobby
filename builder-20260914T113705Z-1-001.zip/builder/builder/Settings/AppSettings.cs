using System;
using System.IO;
using System.Text.Json;

namespace builder.Settings;

/// <summary>Persisted studio settings (%AppData%/BuilderStudio/settings.json).</summary>
public sealed class AppSettings
{
    public static AppSettings Current { get; set; } = new();

    public string WindowMode { get; set; } = "Windowed"; // Windowed | Borderless
    public bool DarkTheme { get; set; } = true;
    public float LookSensitivity { get; set; } = 0.25f;
    public float MoveSpeed { get; set; } = 8f;
    public float LookSmoothing { get; set; } = 18f;
    public float MoveSmoothing { get; set; } = 10f;
    public float Fov { get; set; } = 45f;
    public float FogDensity { get; set; } = 0.012f;
    public bool VSync { get; set; } = true;
    public bool Msaa { get; set; } = true;
    public bool Shadows { get; set; } = true;
    public int ShadowSize { get; set; } = 1024;
    public float ShadowDistance { get; set; } = 20f;
    public float GravityStrength { get; set; } = 20f;
    public float PlayerWalkSpeed { get; set; } = 5f;
    public float PlayerJumpPower { get; set; } = 9f;
    public float PlayerCoyote { get; set; } = 0.12f;
    public float PlayerZoom { get; set; } = 12f;
    public float PlayerSpawnHeight { get; set; } = 6f;
    public float ZoomSpeed { get; set; } = 1f;
    public bool InvertLookY { get; set; } = false;
    public float SelectionGlow { get; set; } = 1f;
    public bool SnapEnabled { get; set; } = true;
    public float Friction { get; set; } = 1f;
    public float TimeOfDay { get; set; } = 10f;
    public int GlMajor { get; set; } = 4;
    public int GlMinor { get; set; } = 0;

    public bool IsBorderless => WindowMode == "Borderless";

    /// <summary>Shadow render-distance presets (studs): Lowest..Maximum.</summary>
    public static readonly float[] ShadowDistancePresets = { 10f, 15f, 20f, 60f, 90f, 120f };

    public static float NearestShadowDistance(float v)
    {
        float best = ShadowDistancePresets[2];
        foreach (float p in ShadowDistancePresets)
            if (Math.Abs(p - v) < Math.Abs(best - v)) best = p;
        return best;
    }

    private static string Path
    {
        get
        {
            string dir = System.IO.Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "BuilderStudio");
            Directory.CreateDirectory(dir);
            return System.IO.Path.Combine(dir, "settings.json");
        }
    }

    public static AppSettings Load()
    {
        try
        {
            if (File.Exists(Path))
            {
                var loaded = JsonSerializer.Deserialize<AppSettings>(File.ReadAllText(Path));
                if (loaded != null) return Sanitize(loaded);
            }
        }
        catch { /* corrupt file -> defaults */ }
        return new AppSettings();
    }

    public void Save()
    {
        try { File.WriteAllText(Path, JsonSerializer.Serialize(this, new JsonSerializerOptions { WriteIndented = true })); }
        catch { /* settings are best-effort */ }
    }

    private static AppSettings Sanitize(AppSettings s)
    {
        if (s.WindowMode != "Borderless") s.WindowMode = "Windowed";
        s.LookSensitivity = Math.Clamp(s.LookSensitivity, 0.05f, 0.6f);
        s.MoveSpeed = Math.Clamp(s.MoveSpeed, 1f, 30f);
        s.LookSmoothing = Math.Clamp(s.LookSmoothing, 4f, 30f);
        s.MoveSmoothing = Math.Clamp(s.MoveSmoothing, 2f, 20f);
        s.Fov = Math.Clamp(s.Fov, 30f, 90f);
        s.FogDensity = Math.Clamp(s.FogDensity, 0f, 0.05f);
        if (s.ShadowSize is not (256 or 512 or 1024 or 2048 or 4096)) s.ShadowSize = 1024;
        s.ShadowDistance = NearestShadowDistance(s.ShadowDistance);
        s.GravityStrength = Math.Clamp(s.GravityStrength, 1f, 50f);
        s.PlayerWalkSpeed = Math.Clamp(s.PlayerWalkSpeed, 1f, 16f);
        s.PlayerJumpPower = Math.Clamp(s.PlayerJumpPower, 1f, 20f);
        s.PlayerCoyote = Math.Clamp(s.PlayerCoyote, 0f, 0.3f);
        s.PlayerZoom = Math.Clamp(s.PlayerZoom, 2f, 120f);
        s.PlayerSpawnHeight = Math.Clamp(s.PlayerSpawnHeight, 2f, 15f);
        s.ZoomSpeed = Math.Clamp(s.ZoomSpeed, 0.25f, 3f);
        s.SelectionGlow = Math.Clamp(s.SelectionGlow, 0f, 1f);
        s.Friction = Math.Clamp(s.Friction, 0f, 2f);
        s.TimeOfDay = Math.Clamp(s.TimeOfDay, 0f, 24f);
        if (!(s.GlMajor == 4 && (s.GlMinor == 6 || s.GlMinor == 0))) { s.GlMajor = 4; s.GlMinor = 0; }
        return s;
    }
}
