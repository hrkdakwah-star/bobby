using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using builder.Settings;

namespace builder;

/// <summary>Live-apply settings dialog. Changes hit the main window immediately; saved on close.</summary>
public partial class SettingsWindow : Window
{
    private readonly MainWindow _main;
    private bool _ready;

    public SettingsWindow(MainWindow main)
    {
        _main = main;
        InitializeComponent();
        Owner = main;

        var s = AppSettings.Current;
        RadioWindowed.IsChecked = !s.IsBorderless;
        RadioBorderless.IsChecked = s.IsBorderless;
        RadioDark.IsChecked = s.DarkTheme;
        RadioLight.IsChecked = !s.DarkTheme;
        SensitivitySlider.Value = s.LookSensitivity;
        SpeedSlider.Value = s.MoveSpeed;
        SensitivityValue.Text = $"{s.LookSensitivity:0.00}";
        SpeedValue.Text = $"{s.MoveSpeed:0}";
        LookSmoothSlider.Value = s.LookSmoothing;
        MoveSmoothSlider.Value = s.MoveSmoothing;
        LookSmoothValue.Text = $"{s.LookSmoothing:0}";
        MoveSmoothValue.Text = $"{s.MoveSmoothing:0}";
        FovSlider.Value = s.Fov;
        FovValue.Text = $"{s.Fov:0}";
        ZoomSpeedSlider.Value = s.ZoomSpeed;
        ZoomSpeedValue.Text = $"{s.ZoomSpeed:0.00}";
        InvertYCheck.IsChecked = s.InvertLookY;
        CheckVSync.IsChecked = _main.VSyncToggle.IsChecked;
        CheckMsaa.IsChecked = _main.MsaaToggle.IsChecked;
        CheckShadows.IsChecked = _main.ShadowsToggle.IsChecked;
        RadioShadowLowest.IsChecked = s.ShadowSize == 256;
        RadioGL46.IsChecked = !(s.GlMajor == 4 && s.GlMinor == 0);
        RadioGL40.IsChecked = s.GlMajor == 4 && s.GlMinor == 0;        RadioShadowLow.IsChecked = s.ShadowSize == 512;
        RadioShadowMed.IsChecked = s.ShadowSize == 1024;
        RadioShadowHigh.IsChecked = s.ShadowSize == 2048;
        RadioShadowUltra.IsChecked = s.ShadowSize == 4096;
        FogSlider.Value = s.FogDensity;
        FogValue.Text = $"{s.FogDensity:0.000}";
        GlowSlider.Value = s.SelectionGlow;
        GlowValue.Text = $"{s.SelectionGlow:0.00}";
        ShadowDistanceBox.SelectedIndex = NearestPresetIndex(s.ShadowDistance);
        SnapDefaultCheck.IsChecked = s.SnapEnabled;
        GravitySlider.Value = s.GravityStrength;
        GravityValue.Text = $"{s.GravityStrength:0}";
        FrictionSlider.Value = s.Friction;
        FrictionValue.Text = $"{s.Friction:0.00}";
        WalkSlider.Value = s.PlayerWalkSpeed;
        WalkValue.Text = $"{s.PlayerWalkSpeed:0}";
        JumpSlider.Value = s.PlayerJumpPower;
        JumpValue.Text = $"{s.PlayerJumpPower:0}";
        ZoomSlider.Value = s.PlayerZoom;
        ZoomValue.Text = $"{s.PlayerZoom:0}";
        SpawnHeightSlider.Value = s.PlayerSpawnHeight;
        SpawnHeightValue.Text = $"{s.PlayerSpawnHeight:0}";
        CoyoteSlider.Value = s.PlayerCoyote;
        CoyoteValue.Text = $"{s.PlayerCoyote:0.00}";

        Closed += (_, _) => s.Save();
        PreviewKeyDown += (_, e) => { if (e.Key == Key.Escape) Close(); };
        Loaded += (_, _) => PlayOpen();
        Closing += OnClosingAnimate;
        _ready = true;
    }

    private static readonly CubicEase EaseOut = new() { EasingMode = EasingMode.EaseOut };

    /// <summary>Fade + grow in.</summary>
    private void PlayOpen()
    {
        Opacity = 0;
        var scale = new ScaleTransform(0.96, 0.96);
        Root.RenderTransform = scale;
        Root.RenderTransformOrigin = new Point(0.5, 0.5);
        BeginAnimation(OpacityProperty,
            new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(160)) { EasingFunction = EaseOut });
        scale.BeginAnimation(ScaleTransform.ScaleXProperty,
            new DoubleAnimation(0.96, 1, TimeSpan.FromMilliseconds(160)) { EasingFunction = EaseOut });
        scale.BeginAnimation(ScaleTransform.ScaleYProperty,
            new DoubleAnimation(0.96, 1, TimeSpan.FromMilliseconds(160)) { EasingFunction = EaseOut });
    }

    private bool _closeAnimated;

    /// <summary>Fade out, then really close (skipped for owner-shutdown fast path).</summary>
    public void CloseImmediate()
    {
        _closeAnimated = true;
        Close();
    }

    private void OnClosingAnimate(object? sender, System.ComponentModel.CancelEventArgs e)
    {
        if (_closeAnimated) return;
        e.Cancel = true;
        _closeAnimated = true;
        var fade = new DoubleAnimation(1, 0, TimeSpan.FromMilliseconds(120)) { EasingFunction = EaseOut };
        fade.Completed += (_, _) => Close();
        BeginAnimation(OpacityProperty, fade);
    }

    private void TitleBar_MouseDown(object sender, MouseButtonEventArgs e)
    {
        if (e.ChangedButton == MouseButton.Left) DragMove();
    }

    /// <summary>Refresh the window-mode radios (e.g. after Esc exits borderless).</summary>
    public void SyncWindowMode()
    {
        _ready = false;
        RadioWindowed.IsChecked = !AppSettings.Current.IsBorderless;
        RadioBorderless.IsChecked = AppSettings.Current.IsBorderless;
        _ready = true;
    }

    private void WindowMode_Checked(object sender, RoutedEventArgs e)
    {
        if (!_ready) return;
        // Sender-based: during a switch the sibling may still read checked.
        _main.ApplyWindowMode(ReferenceEquals(sender, RadioBorderless) ? "Borderless" : "Windowed");
    }

    private void Theme_Checked(object sender, RoutedEventArgs e)
    {
        if (!_ready) return;
        _main.SetTheme(ReferenceEquals(sender, RadioDark));
    }

    private void CameraSlider_Changed(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
        if (!_ready) return;
        var s = AppSettings.Current;
        s.LookSensitivity = (float)SensitivitySlider.Value;
        s.MoveSpeed = (float)SpeedSlider.Value;
        s.LookSmoothing = (float)LookSmoothSlider.Value;
        s.MoveSmoothing = (float)MoveSmoothSlider.Value;
        SensitivityValue.Text = $"{s.LookSensitivity:0.00}";
        SpeedValue.Text = $"{s.MoveSpeed:0}";
        LookSmoothValue.Text = $"{s.LookSmoothing:0}";
        MoveSmoothValue.Text = $"{s.MoveSmoothing:0}";
        _main.ApplyCameraSettings();
    }

    private void FovSlider_Changed(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
        if (!_ready) return;
        FovValue.Text = $"{FovSlider.Value:0}";
        _main.ApplyFov((float)FovSlider.Value);
    }

    private void FogSlider_Changed(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
        if (!_ready) return;
        FogValue.Text = $"{FogSlider.Value:0.000}";
        _main.ApplyFog((float)FogSlider.Value);
    }

    private void GravitySlider_Changed(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
        if (!_ready) return;
        AppSettings.Current.GravityStrength = (float)GravitySlider.Value;
        GravityValue.Text = $"{AppSettings.Current.GravityStrength:0}";
    }

    private void PlayerSlider_Changed(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
        if (!_ready) return;
        var s = AppSettings.Current;
        s.PlayerWalkSpeed = (float)WalkSlider.Value;
        s.PlayerJumpPower = (float)JumpSlider.Value;
        s.PlayerZoom = (float)ZoomSlider.Value;
        s.PlayerSpawnHeight = (float)SpawnHeightSlider.Value;
        s.PlayerCoyote = (float)CoyoteSlider.Value;
        WalkValue.Text = $"{s.PlayerWalkSpeed:0}";
        JumpValue.Text = $"{s.PlayerJumpPower:0}";
        ZoomValue.Text = $"{s.PlayerZoom:0}";
        SpawnHeightValue.Text = $"{s.PlayerSpawnHeight:0}";
        CoyoteValue.Text = $"{s.PlayerCoyote:0.00}";
        _main.ApplyPlayerSettings(); // live: drive reads these every frame
    }

    private void ZoomSpeedSlider_Changed(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
        if (!_ready) return;
        AppSettings.Current.ZoomSpeed = (float)ZoomSpeedSlider.Value;
        ZoomSpeedValue.Text = $"{AppSettings.Current.ZoomSpeed:0.00}";
    }

    private void InvertYCheck_Click(object sender, RoutedEventArgs e)
    {
        if (!_ready) return;
        AppSettings.Current.InvertLookY = InvertYCheck.IsChecked == true;
        _main.ApplyCameraSettings();
    }

    private void GlowSlider_Changed(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
        if (!_ready) return;
        GlowValue.Text = $"{GlowSlider.Value:0.00}";
        _main.ApplySelectionGlow((float)GlowSlider.Value);
    }

    private void SnapDefaultCheck_Click(object sender, RoutedEventArgs e)
    {
        if (!_ready) return;
        _main.ApplySnapDefault(SnapDefaultCheck.IsChecked == true);
    }

    private void FrictionSlider_Changed(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
        if (!_ready) return;
        FrictionValue.Text = $"{FrictionSlider.Value:0.00}";
        _main.ApplyFriction((float)FrictionSlider.Value);
    }

    private void RenderSystem_Checked(object sender, RoutedEventArgs e)
    {
        if (!_ready) return;
        bool fallback = ReferenceEquals(sender, RadioGL40);
        AppSettings.Current.GlMajor = 4;
        AppSettings.Current.GlMinor = fallback ? 0 : 6;
        AppSettings.Current.Save();
    }

    private void ShadowQuality_Checked(object sender, RoutedEventArgs e)    {
        if (!_ready) return;
        int size = ReferenceEquals(sender, RadioShadowLowest) ? 256
            : ReferenceEquals(sender, RadioShadowLow) ? 512
            : ReferenceEquals(sender, RadioShadowHigh) ? 2048
            : ReferenceEquals(sender, RadioShadowUltra) ? 4096
            : 1024;
        _main.RequestShadowSize(size);
    }

    private void ShadowDistanceBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (!_ready || ShadowDistanceBox.SelectedIndex < 0) return;
        _main.ApplyShadowDistance(AppSettings.ShadowDistancePresets[ShadowDistanceBox.SelectedIndex]);
    }

    private static int NearestPresetIndex(float v)
    {
        int best = 2;
        for (int i = 0; i < AppSettings.ShadowDistancePresets.Length; i++)
            if (Math.Abs(AppSettings.ShadowDistancePresets[i] - v) <
                Math.Abs(AppSettings.ShadowDistancePresets[best] - v)) best = i;
        return best;
    }

    private void ViewportCheck_Click(object sender, RoutedEventArgs e)
    {
        _main.ApplyVsync(CheckVSync.IsChecked == true);
        _main.VSyncToggle.IsChecked = CheckVSync.IsChecked;
        _main.ApplyMsaa(CheckMsaa.IsChecked == true);
        _main.MsaaToggle.IsChecked = CheckMsaa.IsChecked;
        _main.ApplyShadows(CheckShadows.IsChecked == true);
        _main.ShadowsToggle.IsChecked = CheckShadows.IsChecked;
    }

    private void Close_Click(object sender, RoutedEventArgs e) => Close();

    /// <summary>TEMPORARY: force-show the GL fallback prompt to test the dialog.</summary>
    private void TestFallbackButton_Click(object sender, RoutedEventArgs e) => _main.TestFallbackPrompt();
}
