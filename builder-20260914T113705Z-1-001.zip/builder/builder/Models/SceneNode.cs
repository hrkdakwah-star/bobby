using System.Collections.ObjectModel;
using System.ComponentModel;

namespace builder.Models;

public sealed class SceneNode : INotifyPropertyChanged
{
    public event PropertyChangedEventHandler? PropertyChanged;
    public string Name { get; set; } = "";
    public string Type { get; set; } = "Part";
    private string _icon = "📦"; // emoji fallback, no image assets needed
    public string Icon
    {
        get => _icon;
        set
        {
            if (_icon != value)
            {
                _icon = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Icon)));
            }
        }
    }
    private string? _iconPath; // embedded PNG (e.g. "Icons/object.png"), null = emoji fallback
    public string? IconPath
    {
        get => _iconPath;
        set
        {
            if (_iconPath != value)
            {
                _iconPath = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IconPath)));
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(HasIconPath)));
            }
        }
    }
    public bool HasIconPath => IconPath != null;

    /// <summary>Live back-reference (a <see cref="Viewport.SceneObject"/> for part nodes, else null).</summary>
    public object? Tag { get; set; }
    public ObservableCollection<SceneNode> Children { get; } = new();

    public SceneNode() { }

    public SceneNode(string name, string type = "Part", string icon = "📦", string? iconPath = null)
    {
        Name = name;
        Type = type;
        _icon = icon;
        _iconPath = iconPath;
    }

    public override string ToString() => Name;

    public static ObservableCollection<SceneNode> CreateDefaultWorkspace()
    {
        // Workspace children are synced from the live 3D scene (see RefreshExplorer).
        var workspace = new SceneNode("Workspace", "Workspace", "🌍", "Icons/object.png");

        var lighting = new SceneNode("Lighting", "Service", "💡", "Icons/light.png");
        lighting.Children.Add(new SceneNode("Sun", "Light", "☀", "Icons/sun.png"));
        lighting.Children.Add(new SceneNode("Atmosphere", "Effect", "☁", "Icons/atmosphere.png"));

        var players = new SceneNode("Players", "Service", "👥");
        players.Children.Add(new SceneNode("Player1", "Player", "🧍"));

        var starterPack = new SceneNode("StarterPack", "Container", "🎒", "Icons/backpack.png");
        var replicatedStorage = new SceneNode("ReplicatedStorage", "Service", "🗄");
        var serverScript = new SceneNode("ServerScriptService", "Service", "📜", "Icons/script.png");

        return new ObservableCollection<SceneNode>
        {
            workspace,
            lighting,
            players,
            starterPack,
            replicatedStorage,
            serverScript
        };
    }
}

public sealed class PropertyRow : INotifyPropertyChanged
{
    public event PropertyChangedEventHandler? PropertyChanged;
    public string Category { get; set; } = "General";
    public string Name { get; set; } = "";
    public string Description { get; set; } = "";
    private string _value = "";
    public string Value
    {
        get => _value;
        set
        {
            if (_value != value)
            {
                _value = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Value)));
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(NumericValue)));
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(ShortValue)));
            }
        }
    }
    public string Type { get; set; } = "string";
    public IReadOnlyList<string>? Choices { get; set; }
    public bool ShowCategory { get; set; }
    /// <summary>Index into <see cref="Viewport.SceneObject.Decals"/> for decal rows, else -1.</summary>
    public int DecalIndex { get; set; } = -1;
    /// <summary>Index into <see cref="Viewport.SceneObject.Texts"/> for text rows, else -1.</summary>
    public int TextIndex { get; set; } = -1;
    public bool IsBoolean => Type == "bool" || Name is "Anchored";
    public bool IsChoice => Choices is { Count: > 0 };
    public bool IsVector => Type == "vector";
    public bool IsColor => Type == "color";
    public bool IsNumber => Type == "number";
    public bool IsFile => Type == "file";
    public bool IsReadOnly => Type == "readonly";
    public bool IsAction => Type == "action";
    public bool BooleanValue
    {
        get => bool.TryParse(Value, out var value) && value;
        set => Value = value.ToString();
    }

    /// <summary>0-1 slider mirror of <see cref="Value"/> (for Transparency/Blur rows).</summary>
    public double NumericValue
    {
        get => double.TryParse(Value, System.Globalization.NumberStyles.Float,
            System.Globalization.CultureInfo.InvariantCulture, out var v) ? v : 0;
        set => Value = value.ToString("0.00", System.Globalization.CultureInfo.InvariantCulture);
    }

    private System.Windows.Media.Brush? _swatch;
    /// <summary>Color preview brush (for Color rows). Updated live, no converter needed.</summary>
    public System.Windows.Media.Brush? Swatch
    {
        get => _swatch;
        set
        {
            if (!Equals(_swatch, value))
            {
                _swatch = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Swatch)));
            }
        }
    }

    private System.Windows.Media.ImageSource? _thumbnail;
    /// <summary>Small decal preview (for Image rows). Null = no image.</summary>
    public System.Windows.Media.ImageSource? Thumbnail
    {
        get => _thumbnail;
        set
        {
            if (!Equals(_thumbnail, value))
            {
                _thumbnail = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Thumbnail)));
            }
        }
    }

    /// <summary>Short file name for tooltips / display (full path stays in <see cref="Value"/>).</summary>
    public string ShortValue
    {
        get
        {
            if (string.IsNullOrWhiteSpace(Value) || Value == "None") return "None";
            try { return System.IO.Path.GetFileName(Value); }
            catch { return Value; }
        }
    }
}
