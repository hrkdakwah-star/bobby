using System.Collections.Generic;
using builder.Viewport;

namespace builder.Models;

/// <summary>
/// On-disk place format (.bp, JSON). Versioned: loaders reject unknown <see cref="Format"/>.
/// Only scene content lives here; render preferences stay in AppSettings.
/// </summary>
public sealed class PlaceFile
{
    public int Format { get; set; } = 1;
    public string App { get; set; } = "builder";
    public List<PartDto> Parts { get; set; } = new();
    public SunDto Sun { get; set; } = new();
    public AtmosphereDto Atmosphere { get; set; } = new();
    public float Ambient { get; set; } = 1f;
    public float TimeOfDay { get; set; } = 10f;
    public CameraDto Camera { get; set; } = new();
}

public sealed class PartDto
{
    public string Name { get; set; } = "Part";
    public ShapeKind Shape { get; set; } = ShapeKind.Block;
    public float[] Position { get; set; } = { 0, 0, 0 };
    public float[] Size { get; set; } = { 2, 2, 2 };
    public float[] Rotation { get; set; } = { 0, 0, 0 };
    public float[] Color { get; set; } = { 0.25f, 0.55f, 0.95f };
    public MaterialKind Material { get; set; } = MaterialKind.Plastic;
    public bool Anchored { get; set; }
    public bool IsSpawn { get; set; }
    public float Mass { get; set; } = 1f;
    public bool CanCollide { get; set; } = true;
    public float Transparency { get; set; }
    public float Reflectance { get; set; }
    public bool CastShadow { get; set; } = true;
    public string? DecalImage { get; set; }
    public string DecalFace { get; set; } = "Front";
    public float DecalTransparency { get; set; }
    public float DecalBlur { get; set; }
    public List<DecalDto> Decals { get; set; } = new();
    public List<TextDto> Texts { get; set; } = new();
}

public sealed class DecalDto
{
    public string Image { get; set; } = "";
    public string Face { get; set; } = "Front";
    public float Transparency { get; set; }
    public float Blur { get; set; }
    public float OffsetX { get; set; }
    public float OffsetY { get; set; }
    public float Scale { get; set; } = 1f;
}

public sealed class TextDto
{
    public string Text { get; set; } = "Text";
    public string Face { get; set; } = "Front";
    public string Font { get; set; } = "Arial";
    public float Size { get; set; } = 48;
    public string Color { get; set; } = "255, 255, 255";
    public float Transparency { get; set; }
    public float Blur { get; set; }
    public float OffsetX { get; set; }
    public float OffsetY { get; set; }
    public float Scale { get; set; } = 1f;
}

public sealed class SunDto
{
    public float[] Direction { get; set; } = { 0.5f, 0.8f, 0.6f };
    public float[] Color { get; set; } = { 1f, 0.97f, 0.92f };
    public float Intensity { get; set; } = 1f;
    public bool Shadows { get; set; } = true;
}

public sealed class AtmosphereDto
{
    public float FogDensity { get; set; } = 0.012f;
    public float[] FogColor { get; set; } = { 0.55f, 0.62f, 0.72f };
    public float Haze { get; set; } = 0.012f;
}

public sealed class CameraDto
{
    public float[] Position { get; set; } = { 0, 1.5f, 8f };
    public float Yaw { get; set; } = -90f;
    public float Pitch { get; set; } = -10f;
}
