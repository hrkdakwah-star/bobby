using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Numerics;
using BepuPhysics;
using BepuPhysics.Collidables;
using BepuPhysics.Trees;
using BepuUtilities.Memory;
using builder.Viewport;
using OTK = OpenTK.Mathematics;

namespace builder.Physics;

/// <summary>
/// Owns the Bepu simulation for Play mode. Anchored parts become statics,
/// everything else dynamic. Edit mode never touches this class.
/// Shapes are added per body and released on Stop (simulation dispose + pool clear),
/// so insert/delete churn during play can't leak.
/// </summary>
public sealed class PhysicsWorld : IDisposable
{
    public const float FixedStep = 1f / 60f;
    public const int MaxSubsteps = 4;

    private BufferPool _pool = new();
    private Simulation? _sim;
    private readonly Dictionary<SceneObject, BodyEntry> _bodies = new();
    private readonly GhostSet _ghosts = new();
    private readonly Dictionary<SceneObject, (OTK.Vector3 Position, OTK.Quaternion Orientation, OTK.Vector3 Rotation)> _snapshots = new();
    private readonly Stopwatch _clock = Stopwatch.StartNew();
    private double _lastTime;
    private float _accumulator;
    private bool _disposed;

    private struct BodyEntry
    {
        public bool IsStatic;
        public BodyHandle Body;
        public StaticHandle Static;
        public TypedIndex Shape;
    }

    /// <summary>Dynamic body handles whose contacts are filtered (ghost parts).</summary>
    public sealed class GhostSet
    {
        public readonly HashSet<int> Bodies = new();
    }

    public bool Simulating => _sim != null;

    // ----- player avatar (Play mode) -----
    // Velocity-driven capsule: WASD sets ground-plane velocity in camera space,
    // gravity owns Y, Space jumps when the downward ray finds support.

    /// <summary>Live player object (in the scene). Null when not playing.</summary>
    public SceneObject? Player { get; private set; }

    /// <summary>Local move input: X = strafe (+right), Z = forward. Set every frame by the UI.</summary>
    public float PlayerMoveX { get; set; }

    public float PlayerMoveZ { get; set; }

    /// <summary>Camera yaw in degrees. Movement is relative to this (Roblox-style).</summary>
    public float PlayerCamYaw { get; set; } = -90f;

    public bool JumpHeld { get; set; }

    /// <summary>Ground speed in studs/s.</summary>
    public float WalkSpeed { get; set; } = 5f;

    /// <summary>Contact friction (0 = ice, 2 = sticky). Read when Play starts.</summary>
    public float Friction { get; set; } = 1f;

    /// <summary>How fast the avatar turns to face movement (higher = snappier).</summary>
    public float TurnResponsiveness { get; set; } = 12f;

    /// <summary>Jump takeoff velocity. ~2 studs of air at the default gravity of 20.</summary>
    public float JumpSpeed { get; set; } = 9f;

    /// <summary>Coyote time: jump still works this long after leaving an edge.</summary>
    public float CoyoteTime { get; set; } = 0.12f;

    /// <summary>Simulated seconds (fixed steps only — pauses/hitches don't count).</summary>
    public double SimTime { get; private set; }

    private double _lastGroundedSimTime = -100;

    /// <summary>Where the avatar (re)spawns. Set by the UI on Play.</summary>
    public OTK.Vector3 SpawnPoint { get; set; } = new(0, 6, 0);

    /// <summary>Falling below this Y respawns the avatar at <see cref="SpawnPoint"/>.</summary>
    public float KillY { get; set; } = -30f;

    /// <summary>Register an already-added scene object as the driven avatar.</summary>
    public void SpawnPlayer(SceneObject p)
    {
        if (_sim == null || Player != null || _bodies.ContainsKey(p)) return;
        p.Orientation = ToOtk(Quaternion.Identity);
        Player = p;
        AddBody(p);
    }

    /// <summary>Forget the avatar (its body dies with the simulation anyway).</summary>
    public void ClearPlayer()
    {
        Player = null;
        FaceObject = null;
        PlayerMoveX = 0;
        PlayerMoveZ = 0;
        JumpHeld = false;
    }

    /// <summary>Face panel tracking the avatar (a ghost part, never simulated).</summary>
    public SceneObject? FaceObject { get; set; }

    /// <summary>Face offset in avatar-local space.</summary>
    public OTK.Vector3 FaceOffset { get; set; } = new(0, 0.2f, 0.38f);

    // ----- OpenTK <-> System.Numerics -----
    private static Vector3 ToNum(OTK.Vector3 v) => new(v.X, v.Y, v.Z);
    private static OTK.Vector3 ToOtk(Vector3 v) => new(v.X, v.Y, v.Z);
    private static Quaternion ToNum(OTK.Quaternion q) => new(q.X, q.Y, q.Z, q.W);
    private static OTK.Quaternion ToOtk(Quaternion q) => new(q.X, q.Y, q.Z, q.W);

    // ----- play control -----

    public bool StartPlay(StudioScene scene, Action<string> log, float gravityStrength)
    {
        if (_sim != null) return true;
        if (scene.Objects.Count == 0)
        {
            log("Play: nothing to simulate.");
            return false;
        }
        _snapshots.Clear();
        foreach (var o in scene.Objects)
        {
            o.ComposeOrientation();
            _snapshots[o] = o.Snapshot();
        }
        var gravity = new Vector3(0, -gravityStrength, 0);
        _ghosts.Bodies.Clear(); // handle values recycle per simulation
        _sim = Simulation.Create(_pool, new StudioNarrowPhaseCallbacks { Friction = Math.Clamp(Friction, 0f, 2f), Ghosts = _ghosts },
            new StudioPoseIntegratorCallbacks(gravity), new SolveDescription(8, 1));
        foreach (var o in scene.Objects) AddBody(o);
        _lastTime = _clock.Elapsed.TotalSeconds;
        _accumulator = 0;
        SimTime = 0;
        _lastGroundedSimTime = -100;
        log($"Playing: {_bodies.Count} bodies (boxes, spheres for balls), gravity {-gravity.Y}.");
        return true;
    }

    public void StopPlay(StudioScene scene)
    {
        if (_sim == null) return;
        foreach (var (o, snap) in _snapshots)
            if (scene.Objects.Contains(o)) o.Restore(snap);
        ClearPlayer();
        _bodies.Clear();
        _ghosts.Bodies.Clear();
        _snapshots.Clear();
        _sim.Dispose();
        _sim = null;
        _pool.Clear();
    }

    /// <summary>Fixed-step the simulation and push poses back to the scene. Call every frame.</summary>
    public void Step(StudioScene scene)
    {
        if (_sim == null || _disposed) return;
        double now = _clock.Elapsed.TotalSeconds;
        _accumulator += (float)Math.Min(now - _lastTime, 0.1);
        _lastTime = now;
        DrivePlayer(); // avatar velocity before the substeps consume it
        int n = 0;
        while (_accumulator >= FixedStep && n < MaxSubsteps)
        {
            _sim.Timestep(FixedStep);
            SimTime += FixedStep;
            _accumulator -= FixedStep;
            n++;
        }
        if (n == MaxSubsteps) _accumulator = 0; // spiral-of-death guard
        foreach (var (o, e) in _bodies)
        {
            if (e.IsStatic) continue;
            BodyReference br = _sim.Bodies[e.Body];
            o.Position = ToOtk(br.Pose.Position);
            o.Orientation = ToOtk(br.Pose.Orientation);
        }
        // Contacts during the substeps can still tilt the avatar: re-lock X/Z
        // after the push so the rendered pose is always upright.
        if (Player != null && _bodies.TryGetValue(Player, out var pe) && !pe.IsStatic)
        {
            BodyReference pbr = _sim.Bodies[pe.Body];
            SnapUpright(pbr, Player);
            pbr.Velocity.Angular = Vector3.Zero;
            Player.Orientation = ToOtk(pbr.Pose.Orientation);
        }
        // Void fall: put the avatar back on its spawn point.
        if (Player != null && Player.Position.Y < KillY)
            RespawnPlayer();
        // Face panel rides the avatar (ghost: transform only, no body).
        if (Player != null && FaceObject != null)
        {
            FaceObject.Position = Player.Position +
                ToOtk(Vector3.Transform(ToNum(FaceOffset), ToNum(Player.Orientation)));
            FaceObject.Orientation = Player.Orientation;
        }
    }

    /// <summary>Kill pitch/roll on an avatar body, preserving yaw.</summary>
    private static void SnapUpright(BodyReference br, SceneObject o)
    {
        var fwd = Vector3.Transform(new Vector3(0, 0, 1), br.Pose.Orientation);
        float yaw = MathF.Atan2(fwd.X, fwd.Z);
        var upright = Quaternion.CreateFromAxisAngle(Vector3.UnitY, yaw);
        br.Pose.Orientation = upright;
        o.Orientation = ToOtk(upright);
    }

    private void RespawnPlayer()
    {
        if (_sim == null || Player == null || !_bodies.TryGetValue(Player, out var e) || e.IsStatic) return;
        BodyReference br = _sim.Bodies[e.Body];
        br.Pose.Position = ToNum(SpawnPoint);
        br.Pose.Orientation = Quaternion.Identity;
        br.Velocity.Linear = Vector3.Zero;
        br.Velocity.Angular = Vector3.Zero;
        Player.Position = SpawnPoint;
        Player.Orientation = ToOtk(Quaternion.Identity);
        _sim.Awakener.AwakenBody(e.Body);
    }

    // ----- player driving -----

    private void DrivePlayer()
    {
        if (_sim == null || Player == null || !_bodies.TryGetValue(Player, out var e) || e.IsStatic) return;
        BodyReference br = _sim.Bodies[e.Body];
        // Camera-relative wish direction on the ground plane.
        float yaw = PlayerCamYaw * MathF.PI / 180f;
        var fwd = new Vector3(MathF.Cos(yaw), 0, MathF.Sin(yaw));
        var rgt = new Vector3(-MathF.Sin(yaw), 0, MathF.Cos(yaw));
        var wish = fwd * PlayerMoveZ + rgt * PlayerMoveX;
        if (wish.LengthSquared() > 1f) wish = Vector3.Normalize(wish);
        if (wish.LengthSquared() > 0.0001f)
        {
            // Face the walk direction (X/Z stay locked, yaw eases; face panel follows).
            var fwd0 = Vector3.Transform(new Vector3(0, 0, 1), br.Pose.Orientation);
            float cur = MathF.Atan2(fwd0.X, fwd0.Z);
            float d = MathF.Atan2(wish.X, wish.Z) - cur;
            while (d > MathF.PI) d -= 2f * MathF.PI;
            while (d < -MathF.PI) d += 2f * MathF.PI;
            float t = 1f - MathF.Exp(-TurnResponsiveness * FixedStep);
            var faceYaw = Quaternion.CreateFromAxisAngle(Vector3.UnitY, cur + d * t);
            br.Pose.Orientation = faceYaw;
            Player.Orientation = ToOtk(faceYaw);
        }
        else SnapUpright(br, Player); // idle: hold facing, kill any pitch/roll
        var vel = br.Velocity.Linear;
        vel.X = wish.X * WalkSpeed;
        vel.Z = wish.Z * WalkSpeed;
        bool grounded = IsGrounded(Player);
        if (grounded) _lastGroundedSimTime = SimTime;
        if (JumpHeld && (grounded || SimTime - _lastGroundedSimTime <= CoyoteTime)) vel.Y = JumpSpeed;
        br.Velocity.Linear = vel;
        br.Velocity.Angular = Vector3.Zero;
        if (wish.LengthSquared() > 0.0001f || JumpHeld) _sim.Awakener.AwakenBody(e.Body);
    }

    /// <summary>Support check: short ray down from the center (ignores the avatar itself).</summary>
    public bool IsGrounded(SceneObject o)
    {
        if (_sim == null || !_bodies.TryGetValue(o, out var e) || e.IsStatic) return false;
        var origin = ToNum(o.Position);
        var dir = new Vector3(0, -1, 0);
        float maxT = o.Size.Y * 0.5f + 0.15f;
        var handler = new GroundHit { Ignore = e.Body, Ghosts = _ghosts };
        _sim.RayCast(in origin, in dir, maxT, ref handler, 0);
        return handler.Hit;
    }

    private struct GroundHit : IRayHitHandler
    {
        public BodyHandle Ignore;
        public GhostSet? Ghosts;
        public bool Hit;

        public bool AllowTest(CollidableReference c)
        {
            if (c.Mobility != CollidableMobility.Dynamic) return true;
            if (c.BodyHandle.Value == Ignore.Value) return false;
            return Ghosts == null || !Ghosts.Bodies.Contains(c.BodyHandle.Value); // no standing on ghosts
        }

        public bool AllowTest(CollidableReference c, int childIndex) => AllowTest(c);

        public void OnRayHit(in RayData ray, ref float maximumT, float t, in Vector3 normal, CollidableReference collidable, int childIndex)
        {
            Hit = true;
            maximumT = t;
        }
    }

    // ----- body management -----

    public void AddBody(SceneObject o)
    {
        if (_sim == null || _bodies.ContainsKey(o)) return;
        // Anchored ghosts need nothing (frozen is correct); unanchored ghosts get
        // a real dynamic body whose contacts are filtered (gravity, no collision).
        if (!o.CanCollide && o.Anchored) return;
        var (index, inertia) = BuildShape(o);
        var pose = new RigidPose
        {
            Position = ToNum(o.Position),
            Orientation = ToNum(o.Orientation),
        };
        if (o.Anchored)
        {
            var sh = _sim.Statics.Add(new StaticDescription(pose, index));
            _bodies[o] = new BodyEntry { IsStatic = true, Static = sh, Shape = index };
        }
        else
        {
            var bh = _sim.Bodies.Add(BodyDescription.CreateDynamic(pose.Position, inertia, index, 0.01f));
            BodyReference br = _sim.Bodies[bh];
            br.Pose.Orientation = pose.Orientation;
            _bodies[o] = new BodyEntry { IsStatic = false, Body = bh, Shape = index };
            if (!o.CanCollide) _ghosts.Bodies.Add(bh.Value);
        }
    }

    public void RemoveBody(SceneObject o)
    {
        if (_sim == null || !_bodies.TryGetValue(o, out var e)) return;
        if (e.IsStatic) _sim.Statics.Remove(e.Static);
        else
        {
            _ghosts.Bodies.Remove(e.Body.Value);
            _sim.Bodies.Remove(e.Body);
        }
        _bodies.Remove(o);
    }

    /// <summary>Rebuild a body in place (size/shape/anchor/mass changed), keeping pose + velocity.</summary>
    public void RecreateBody(SceneObject o)
    {
        if (_sim == null) return;
        if (!_bodies.TryGetValue(o, out var e))
        {
            // No body yet (e.g. CanCollide flipped back on): create if collidable.
            if (o.CanCollide) AddBody(o);
            return;
        }
        BodyVelocity vel = default;
        bool dyn = !e.IsStatic;
        if (dyn) vel = _sim.Bodies[e.Body].Velocity;
        RemoveBody(o);
        AddBody(o);
        if (dyn && _bodies.TryGetValue(o, out var ne) && !ne.IsStatic)
        {
            BodyReference br = _sim.Bodies[ne.Body];
            br.Velocity.Linear = vel.Linear;
            br.Velocity.Angular = vel.Angular;
            _sim.Awakener.AwakenBody(ne.Body);
        }
    }

    /// <summary>Teleport a body to its object's transform (gizmo drags, property edits).</summary>
    public void Teleport(SceneObject o)
    {
        if (_sim == null || !_bodies.TryGetValue(o, out var e)) return;
        var pose = new RigidPose
        {
            Position = ToNum(o.Position),
            Orientation = ToNum(o.Orientation),
        };
        if (e.IsStatic)
        {
            _sim.Statics.Remove(e.Static);
            var sh = _sim.Statics.Add(new StaticDescription(pose, e.Shape));
            e.Static = sh;
            _bodies[o] = e;
        }
        else
        {
            BodyReference br = _sim.Bodies[e.Body];
            br.Pose.Position = pose.Position;
            br.Pose.Orientation = pose.Orientation;
            br.Velocity.Linear = Vector3.Zero;
            br.Velocity.Angular = Vector3.Zero;
            _sim.Awakener.AwakenBody(e.Body);
        }
    }

    // ----- shapes -----
    //
    // Roblox-style CollisionFidelity = Box: parts collide as centered primitives
    // matching their size (boxes for everything, real spheres for balls and real
    // capsules for capsule parts). The avatar is special-cased to a flat-sided
    // cylinder: a capsule foot rolls up vertical faces (wall climbing). No hulls,
    // no compounds, no COM offsets that could shift contact.

    private (TypedIndex Index, BodyInertia Inertia) BuildShape(SceneObject o)
    {
        var sim = _sim!;
        var s = o.Size;
        // Explicit per-part mass (Properties > Mass, default 1). Collision size
        // still comes from Size; only the heaviness changes.
        float mass = Math.Max(o.Mass, 0.01f);
        if (ReferenceEquals(o, Player))
        {
            // Avatar: flat-sided cylinder, never a capsule. The capsule's round
            // foot rolls up vertical faces (wall climbing); a flat side just
            // slides. Matches the mesh bounds: r from X/Z, height from Y.
            float pr = Math.Max(Math.Max(s.X, s.Z) * 0.25f, 0.05f);
            float h = Math.Max(s.Y, 0.1f);
            var cyl = new Cylinder(pr, h);
            return (sim.Shapes.Add(cyl), cyl.ComputeInertia(mass));
        }
        if (o.Shape == Viewport.ShapeKind.Capsule)
        {
            // Unit mesh: r=.25 ring, total height 1. Radius scales with X/Z, height with Y.
            float r = Math.Max(Math.Max(s.X, s.Z) * 0.25f, 0.05f);
            float len = Math.Max(s.Y - 2f * r, 0.05f);
            var capsule = new Capsule(r, len);
            return (sim.Shapes.Add(capsule), capsule.ComputeInertia(mass));
        }
        if (o.Shape == Viewport.ShapeKind.Ball)
        {
            float r = (s.X + s.Y + s.Z) / 6f;
            var sphere = new Sphere(r);
            var inertia = sphere.ComputeInertia(mass);
            return (sim.Shapes.Add(sphere), inertia);
        }
        var box = new Box(s.X, s.Y, s.Z);
        var boxInertia = box.ComputeInertia(mass);
        return (sim.Shapes.Add(box), boxInertia);
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        _bodies.Clear();
        _ghosts.Bodies.Clear();
        _snapshots.Clear();
        _sim?.Dispose();
        _sim = null;
        _pool.Clear();
    }
}
